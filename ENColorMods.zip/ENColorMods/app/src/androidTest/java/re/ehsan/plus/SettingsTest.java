package re.ehsan.plus;

import junit.framework.TestCase;

/**
 * Created by Mr_ehsan on 22/10/15.
 */
public class SettingsTest extends TestCase {

    public void testOnCreate() throws Exception {

    }
}