package com.enwhatsapp;

import android.app.Activity;

/**
 * Created by Mr_ehsan on 26/12/15.
 */
public class TextEmojiLabel extends Activity {

    public void setTextColor(int textColor) {
       textColor = textColor;
    }

    public void setTextSize(float textSize) {
        textSize = textSize;
    }

    public void setTextIsSelectable(boolean b) {

    }
}
