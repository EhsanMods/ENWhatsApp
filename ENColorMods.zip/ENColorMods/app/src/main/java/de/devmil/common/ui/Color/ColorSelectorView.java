/*
 * Copyright (C) 2011 Devmil (Michael Lamers) 
 * Mail: develmil@googlemail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.devmil.common.ui.Color;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabContentFactory;
import android.widget.TabHost.TabSpec;

import re.ehsan.plus.EhsanMods;

public class ColorSelectorView extends LinearLayout {
	private static final String HSV_TAG = "HSV";
	private static final String RGB_TAG = "RGB";
	private static final String HEX_TAG = "HEX";

	private RgbSelectorView rgbSelector;
	private HsvSelectorView hsvSelector;
	private HexSelectorView hexSelector;
	private TabHost tabs;
	
	private int maxHeight = 0;
	private int maxWidth = 0;

	private int color;
	
	private OnColorChangedListener listener;

	public ColorSelectorView(Context context) {
		super(context);
		init();
	}

	public ColorSelectorView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public void setColor(int color) {
		setColor(color, null);
	}

	private void setColor(int color, View sender) {
		if (this.color == color)
			return;
		this.color = color;
		if (sender != hsvSelector)
			hsvSelector.setColor(color);
		if (sender != rgbSelector)
			rgbSelector.setColor(color);
		if (sender != hexSelector)
			hexSelector.setColor(color);
		onColorChanged();
	}

	public int getColor() {
		return color;
	}

	private void init() {
		LayoutInflater inflater = (LayoutInflater) getContext()
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View contentView = inflater.inflate(EhsanMods.getResId(getContext(),"color_colorselectview","layout"),
				null);

		addView(contentView, new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));

		hsvSelector = new HsvSelectorView(getContext());
		hsvSelector.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		hsvSelector
				.setOnColorChangedListener(new HsvSelectorView.OnColorChangedListener() {
					@Override
					public void colorChanged(int color) {
						setColor(color);
					}
				});
		rgbSelector = new RgbSelectorView(getContext());
		rgbSelector.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		rgbSelector
				.setOnColorChangedListener(new RgbSelectorView.OnColorChangedListener() {
					@Override
					public void colorChanged(int color) {
						setColor(color);
					}
				});
		hexSelector = new HexSelectorView(getContext());
		hexSelector.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		hexSelector
				.setOnColorChangedListener(new HexSelectorView.OnColorChangedListener() {
					@Override
					public void colorChanged(int color) {
						setColor(color);
					}
				});

		tabs = (TabHost) contentView
				.findViewById(EhsanMods.getResId(getContext(),"colorview_tabColors","id"));
		tabs.setup();
		ColorTabContentFactory factory = new ColorTabContentFactory();
		TabSpec hsvTab = tabs.newTabSpec(HSV_TAG).setIndicator("HSV", getContext().getResources().getDrawable(EhsanMods.getResId(getContext(),"hsv32","drawable")))
				.setContent(factory);
		TabSpec rgbTab = tabs.newTabSpec(RGB_TAG).setIndicator("RGB", getContext().getResources().getDrawable(EhsanMods.getResId(getContext(),"rgb32","drawable")))
				.setContent(factory);
		TabSpec hexTab = tabs.newTabSpec(HEX_TAG).setIndicator("HEX", getContext().getResources().getDrawable(EhsanMods.getResId(getContext(),"hex32","drawable")))
				.setContent(factory);
		tabs.addTab(hsvTab);
		tabs.addTab(rgbTab);
		tabs.addTab(hexTab);
	}

	class ColorTabContentFactory implements TabContentFactory {
		@Override
		public View createTabContent(String tag) {
			if (HSV_TAG.equals(tag)) {
				return hsvSelector;
			}
			if (RGB_TAG.equals(tag)) {
				return rgbSelector;
			}
			if (HEX_TAG.equals(tag)) {
				return hexSelector;
			}
			return null;
		}
	}
	
	private void onColorChanged()
	{
		if(listener != null)
			listener.colorChanged(getColor());
	}
	
	public void setOnColorChangedListener(OnColorChangedListener listener)
	{
		this.listener = listener;
	}
	
	public interface OnColorChangedListener
	{
		public void colorChanged(int color);
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		if(HSV_TAG.equals(tabs.getCurrentTabTag()))
		{
			maxHeight = getMeasuredHeight();
			maxWidth = getMeasuredWidth();
		}
		setMeasuredDimension(maxWidth, maxHeight);
	}
}
