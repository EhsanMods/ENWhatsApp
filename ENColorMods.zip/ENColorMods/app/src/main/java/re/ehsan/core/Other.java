package re.ehsan.core;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import re.ehsan.plus.EhsanMods;

/**
 * Created by Mr_ehsan on 31/12/15.
 */
public class Other extends PreferenceActivity implements Preference.OnPreferenceClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_other", "xml"));
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        findPreference("clear_logs").setOnPreferenceClickListener(this);
        findPreference("CreateShortcut").setOnPreferenceClickListener(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference.getKey().equals("clear_logs")) {
            EhsanMods.ClearLogs(this);
        }else if(preference.getKey().equals("CreateShortcut")){
            EhsanMods.getCreateShortcutIcon(this);

        }

        return false;
    }

    SharedPreferences.OnSharedPreferenceChangeListener check = new SharedPreferences.OnSharedPreferenceChangeListener(){
        public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            if(!key.equals("status_toast_check")
                    && !key.equals("Conv_call_btn")
                    && !key.equals("always_online_check")
                    && !key.equals("TxtSelect")
                    && !key.equals("Archv_chats")
                    && !key.equals("chats_show_contact_online_toast_check")
                    && !key.equals("chats_play_contact_online_tone")
                    && !key.equals("chats_show_my_name_check")
                    && !key.equals("status_chats_check")
                    && !key.equals("statuschat")
                    && !key.equals("Audio_sensor")
                    && !key.equals("Audio_ears")
                    && !key.equals("Img_share_limit")
                    || !key.equals("Up_size_limit"));

            {
                EhsanMods.isRestart= true;
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(check);
    }



    @Override
    protected void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(check);

    }

}
