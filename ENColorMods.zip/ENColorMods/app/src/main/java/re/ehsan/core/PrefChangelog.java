package re.ehsan.core;

import android.content.Context;
import android.content.Intent;
import android.preference.Preference;
import android.util.AttributeSet;

import re.ehsan.plus.ChangeLog;

/**
 * Created by Mr_ehsan on 03/01/16.
 */
public class PrefChangelog extends Preference implements android.preference.Preference.OnPreferenceClickListener{

    private ChangeLog cl = null;

    public PrefChangelog(Context context){
        super(context);
        init();
        cl = new ChangeLog(context);

    }

    public PrefChangelog(Context context, AttributeSet attributeset){
        super(context, attributeset);
        init();
        cl = new ChangeLog(context);
    }

    public PrefChangelog(Context context, AttributeSet attributeset, int i){
        super(context, attributeset, i);
        init();
        cl = new ChangeLog(context);
    }

    public void init(){
        setOnPreferenceClickListener(this);

    }


    @Override
    public boolean onPreferenceClick(Preference preference) {
        PrefChangelog.this.cl.getFullLogDialog().show();
        return false;
    }

}