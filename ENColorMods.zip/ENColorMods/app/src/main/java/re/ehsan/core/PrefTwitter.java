package re.ehsan.core;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.preference.Preference;
import android.util.AttributeSet;

/**
 * Created by Mr_ehsan on 03/01/16.
 */
public class PrefTwitter extends Preference implements android.preference.Preference.OnPreferenceClickListener{

    public PrefTwitter(Context context){
        super(context);
        init();

    }

    public PrefTwitter(Context context, AttributeSet attributeset){
        super(context, attributeset);
        init();
    }

    public PrefTwitter(Context context, AttributeSet attributeset, int i){
        super(context, attributeset, i);
        init();
    }

    public void init(){
        setOnPreferenceClickListener(this);

    }


    @Override
    public boolean onPreferenceClick(Preference preference) {
        Intent i= new Intent("android.intent.action.VIEW", Uri.parse("https://twitter.com/mr_ehsan2012"));
        getContext().startActivity(i);
        return false;
    }



}

