package re.ehsan.core;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.preference.Preference;
import android.util.AttributeSet;

/**
 * Created by Mr_ehsan on 03/01/16.
 */
public class PrefWeb extends Preference implements android.preference.Preference.OnPreferenceClickListener{

    public PrefWeb(Context context){
        super(context);
        init();

    }

    public PrefWeb(Context context, AttributeSet attributeset){
        super(context, attributeset);
        init();
    }

    public PrefWeb(Context context, AttributeSet attributeset, int i){
        super(context, attributeset, i);
        init();
    }

    public void init(){
        setOnPreferenceClickListener(this);

    }


    @Override
    public boolean onPreferenceClick(Preference preference) {
        Intent i= new Intent("android.intent.action.VIEW", Uri.parse("http://www.ehsan.re"));
        getContext().startActivity(i);
        return false;
    }

}