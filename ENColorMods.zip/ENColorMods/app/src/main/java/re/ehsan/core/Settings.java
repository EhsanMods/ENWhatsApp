package re.ehsan.core;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import re.ehsan.plus.*;

/**
 * Created by Mr_ehsan on 31/12/15.
 */
public class Settings extends PreferenceActivity implements Preference.OnPreferenceClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_settings", "xml"));
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        PrefKeys();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                if (EhsanMods.isRestart) {
                    //EhsanMods.isRestart = false;
                    EhsanMods.RestartApp();
                }
            }
        });

    }

    private void PrefKeys(){
        findPreference("update_key").setOnPreferenceClickListener(this);
        findPreference("donate").setOnPreferenceClickListener(this);
        findPreference("enprivacy").setOnPreferenceClickListener(this);
        findPreference("CreateShortcut").setOnPreferenceClickListener(this);
        findPreference("en_other").setOnPreferenceClickListener(this);
        findPreference("about").setOnPreferenceClickListener(this);
        findPreference("google").setOnPreferenceClickListener(this);
        findPreference("enmods").setOnPreferenceClickListener(this);
        findPreference("share").setOnPreferenceClickListener(this);
        findPreference("en_twitter").setOnPreferenceClickListener(this);
        findPreference("report").setOnPreferenceClickListener(this);

    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference.getKey().equals("update_key")) {
            Intent i= new Intent(this, Update.class);
            this.startActivity(i);

        }else if(preference.getKey().equals("enprivacy")){
            Intent intent = new Intent(this, Privacy.class);
            this.startActivity(intent);

        }else if(preference.getKey().equals("CreateShortcut")){
            EhsanMods.getCreateShortcutIcon(this);

        }else if(preference.getKey().equals("en_other")){
            Intent intent = new Intent(this, Other.class);
            this.startActivity(intent);

        }else if(preference.getKey().equals("about")){
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://www.ehsan.re"));
            this.startActivity(intent);

        }else if(preference.getKey().equals("google")){
            Intent i= new Intent("android.intent.action.VIEW", Uri.parse("https://plus.google.com/u/0/118205324212130186262"));
            this.startActivity(i);

        }else if(preference.getKey().equals("enmods")){
            Intent i= new Intent("android.intent.action.VIEW", Uri.parse("https://plus.google.com/u/0/communities/105039905761791987988"));
            this.startActivity(i);

        }else if(preference.getKey().equals("share")){
            EhsanMods.getShare(this, EhsanMods.getString("ENShareSbj", this), EhsanMods.getString("ENShareBdy", this), EhsanMods.getString("ENShare", this));

        }else if(preference.getKey().equals("donate")){
            Intent i= new Intent("android.intent.action.VIEW", Uri.parse("https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ehsan2022%40hotmail%2ecom&lc=US&item_name=Donate%20to%20EhsanMods&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted"));
            this.startActivity(i);

        }else if(preference.getKey().equals("en_twitter")){
            Intent i= new Intent("android.intent.action.VIEW", Uri.parse("https://twitter.com/Mr_ehsan2012"));
            this.startActivity(i);

        }else if(preference.getKey().equals("report")){
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("message/rfc822");
            i.putExtra(Intent.EXTRA_EMAIL  , new String[] { "info@ehsan.re" });
            i.putExtra(Intent.EXTRA_SUBJECT, EhsanMods.getString("EN_Version", this));
            try {
                startActivity(Intent.createChooser(i, "Send mail..."));
            } catch (android.content.ActivityNotFoundException ex) {
                Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
            }

        }

        return false;
    }

    SharedPreferences.OnSharedPreferenceChangeListener check = new SharedPreferences.OnSharedPreferenceChangeListener(){
        public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            if(!key.equals("en_icons")){
            EhsanMods.ClearLogs(Settings.this);
           }
        }

    };

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(check);
    }



    @Override
    protected void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(check);

    }

    @Override
    protected void onStart() {
        super.onStart();
        // Monitor launch times and interval from installation
        FollowApp.onStart(this);
        // Show a dialog if criteria is satisfied
        FollowApp.showFollowDialogIfNeeded(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(EhsanMods.isRestart) {
            //EhsanMods.isRestart = false;
            EhsanMods.RestartApp();
        }
    }

}