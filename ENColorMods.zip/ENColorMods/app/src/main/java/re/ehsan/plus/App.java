package re.ehsan.plus;

import android.app.Activity;
import android.app.Application;
import android.content.Context;

/**
 * Created by Mr_ehsan on 07/12/15.
 */


public class App extends Application {

    @Override
    public void onCreate() {

        EhsanMods.init(this);
        super.onCreate();

    }


    public static Object b(Context context) {
        // TODO Auto-generated method stub
        return null;
    }

}
