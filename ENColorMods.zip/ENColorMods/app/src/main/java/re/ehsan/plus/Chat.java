package re.ehsan.plus;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by Mr_ehsan on 19/10/15.
 */
public class Chat extends PreferenceActivity implements Preference.OnPreferenceClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_chat", "xml"));
        findPreference("en_chat_header").setOnPreferenceClickListener(this);
        findPreference("en_chat_mod").setOnPreferenceClickListener(this);
        findPreference("en_chat_transparent").setOnPreferenceClickListener(this);
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference.getKey().equals("en_chat_header")) {
            Intent i= new Intent(this, ChatHeader.class);
            this.startActivity(i);

        } else if (preference.getKey().equals("en_chat_mod")) {
            Intent i= new Intent(this, ChatMod.class);
            this.startActivity(i);

        }else if (preference.getKey().equals("en_chat_transparent")) {
            Intent i= new Intent(this, ChatTransparent.class);
            this.startActivity(i);
        }

        return false;
    }



}

