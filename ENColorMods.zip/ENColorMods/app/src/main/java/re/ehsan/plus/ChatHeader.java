package re.ehsan.plus;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import de.devmil.common.ui.Color.ColorSelectorDialog;

/**
 * Created by Mr_ehsan on 26/10/15.
 */
public class ChatHeader extends PreferenceActivity implements Preference.OnPreferenceClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_chat_header", "xml"));
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        PrefKeys();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void PrefKeys(){
        findPreference("chat_header_background_color_picker").setOnPreferenceClickListener(this);
        findPreference("chat_header_icons_color_picker").setOnPreferenceClickListener(this);
        findPreference("contact_name_color_picker").setOnPreferenceClickListener(this);
        findPreference("contact_status_color_picker").setOnPreferenceClickListener(this);
        findPreference("last_seen_color_picker").setOnPreferenceClickListener(this);
        findPreference("online_color_picker").setOnPreferenceClickListener(this);
        findPreference("typing_color_picker").setOnPreferenceClickListener(this);
        findPreference("chat_attach_icons_holo_text_color_picker").setOnPreferenceClickListener(this);
        findPreference("chat_attach_bg_color_picker").setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference.getKey().equals("chat_header_background_color_picker")) {
            EhsanMods.getShowColor(this, "chat_header_background_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("chat_header_icons_color_picker")){
            EhsanMods.getShowColor(this, "chat_header_icons_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("contact_name_color_picker")){
            EhsanMods.getShowColor(this, "contact_name_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("contact_status_color_picker")){
            EhsanMods.getShowColor(this, "contact_status_color_picker", Color.WHITE);

        }else if(preference.getKey().equals("last_seen_color_picker")){
            EhsanMods.getShowColor(this, "last_seen_color_picker", Color.WHITE);

        }else if(preference.getKey().equals("online_color_picker")){
            EhsanMods.getShowColor(this, "online_color_picker", Color.WHITE);

        }else if(preference.getKey().equals("typing_color_picker")){
            EhsanMods.getShowColor(this, "typing_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("chat_attach_icons_holo_text_color_picker")){
            EhsanMods.getShowColor(this,"chat_attach_icons_holo_text_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("chat_attach_bg_color_picker")){
            EhsanMods.getShowColor(this,"chat_attach_bg_color_picker", EhsanMods.defColor);

        }
        return EhsanMods.isRestart= true;
    }

    SharedPreferences.OnSharedPreferenceChangeListener check = new SharedPreferences.OnSharedPreferenceChangeListener(){
        public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            if(!key.equals("bold_names_check")
                    && !key.equals("chat_open_profile_pic_disabled_check")
                    && !key.equals("chat_hide_call_icon_check")
                    || !key.equals("chat_hide_contact_pic_check"));

            {
                EhsanMods.isRestart= true;
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(check);
    }



    @Override
    protected void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(check);

    }
}