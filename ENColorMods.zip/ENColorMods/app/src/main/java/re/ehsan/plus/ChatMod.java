package re.ehsan.plus;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import de.devmil.common.ui.Color.ColorSelectorDialog;

/**
 * Created by Mr_ehsan on 26/10/15.
 */
public class ChatMod extends PreferenceActivity implements Preference.OnPreferenceClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_chat_mod", "xml"));
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        PrefKeys();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void PrefKeys(){
        findPreference("background_color_picker").setOnPreferenceClickListener(this);
        findPreference("message_link_color_picker").setOnPreferenceClickListener(this);
        findPreference("right_message_text_color_picker").setOnPreferenceClickListener(this);
        findPreference("left_message_text_color_picker").setOnPreferenceClickListener(this);
        findPreference("grey_bubble_color_picker").setOnPreferenceClickListener(this);
        findPreference("green_bubble_color_picker").setOnPreferenceClickListener(this);
        findPreference("date_right_color_picker").setOnPreferenceClickListener(this);
        findPreference("date_color_picker").setOnPreferenceClickListener(this);
        findPreference("status_color_picker").setOnPreferenceClickListener(this);
        findPreference("status_read_color_picker").setOnPreferenceClickListener(this);
        findPreference("date_divider_color_picker").setOnPreferenceClickListener(this);
        findPreference("date_bubble_color_picker").setOnPreferenceClickListener(this);
        findPreference("participant_name_color_picker").setOnPreferenceClickListener(this);
        findPreference("emoji_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("send_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("camera_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("mic_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("mic_circle_mod_picker").setOnPreferenceClickListener(this);
        findPreference("edit_layout_bg_color_picker").setOnPreferenceClickListener(this);
        findPreference("text_entry_color_picker").setOnPreferenceClickListener(this);
        findPreference("text_entry_bg_color_picker").setOnPreferenceClickListener(this);
        findPreference("emoji_selected_color_picker").setOnPreferenceClickListener(this);
        findPreference("emoji_selected_view_color_picker").setOnPreferenceClickListener(this);
        findPreference("emoji_bg_header_color_picker").setOnPreferenceClickListener(this);
        findPreference("emoji_bg_body_color_picker").setOnPreferenceClickListener(this);
        findPreference("chat_load_earlier_msgs_text_color_picker").setOnPreferenceClickListener(this);
        findPreference("chat_load_earlier_msgs_bg_color_picker").setOnPreferenceClickListener(this);
        findPreference("caption_color_picker").setOnPreferenceClickListener(this);
        findPreference("contact_global_status_mod_picker").setOnPreferenceClickListener(this);
        findPreference("contact_global_bg_status_mod_picker").setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference.getKey().equals("background_color_picker")) {
            EhsanMods.getShowColor(this, "background_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("message_link_color_picker")){
            EhsanMods.getShowColor(this, "message_link_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("right_message_text_color_picker")){
            EhsanMods.getShowColor(this, "right_message_text_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("left_message_text_color_picker")){
            EhsanMods.getShowColor(this, "left_message_text_color_picker", Color.WHITE);

        }else if(preference.getKey().equals("grey_bubble_color_picker")){
            EhsanMods.getShowColor(this, "grey_bubble_color_picker", Color.WHITE);

        }else if(preference.getKey().equals("green_bubble_color_picker")){
            EhsanMods.getShowColor(this, "green_bubble_color_picker", Color.WHITE);

        }else if(preference.getKey().equals("date_right_color_picker")){
            EhsanMods.getShowColor(this, "date_right_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("date_color_picker")){
            EhsanMods.getShowColor(this, "date_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("status_color_picker")){
            EhsanMods.getShowColor(this, "status_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("status_read_color_picker")){
            EhsanMods.getShowColor(this, "status_read_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("date_divider_color_picker")){
            EhsanMods.getShowColor(this, "date_divider_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("date_bubble_color_picker")){
            EhsanMods.getShowColor(this, "date_bubble_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("participant_name_color_picker")){
            EhsanMods.getShowColor(this, "participant_name_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("emoji_icon_color_picker")){
            EhsanMods.getShowColor(this, "emoji_icon_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("send_icon_color_picker")){
            EhsanMods.getShowColor(this, "send_icon_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("camera_icon_color_picker")){
            EhsanMods.getShowColor(this, "camera_icon_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("mic_icon_color_picker")){
            EhsanMods.getShowColor(this, "mic_icon_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("mic_circle_mod_picker")){
            EhsanMods.getShowColor(this, "mic_circle_mod_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("edit_layout_bg_color_picker")){
            EhsanMods.getShowColor(this, "edit_layout_bg_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("text_entry_color_picker")){
            EhsanMods.getShowColor(this, "text_entry_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("text_entry_bg_color_picker")){
            EhsanMods.getShowColor(this, "text_entry_bg_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("emoji_selected_color_picker")){
            EhsanMods.getShowColor(this, "emoji_selected_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("emoji_selected_view_color_picker")){
            EhsanMods.getShowColor(this, "emoji_selected_view_color_picker", EhsanMods.defColor);

        }else if(preference.getKey().equals("emoji_bg_header_color_picker")){
            EhsanMods.getShowColor(this, "emoji_bg_header_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("emoji_bg_body_color_picker")){
            EhsanMods.getShowColor(this, "emoji_bg_body_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("chat_load_earlier_msgs_text_color_picker")){
            EhsanMods.getShowColor(this, "chat_load_earlier_msgs_text_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("chat_load_earlier_msgs_bg_color_picker")){
            EhsanMods.getShowColor(this, "chat_load_earlier_msgs_bg_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("caption_color_picker")){
            EhsanMods.getShowColor(this, "caption_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("contact_global_status_mod_picker")){
            EhsanMods.getShowColor(this, "contact_global_status_mod_picker", Color.WHITE);

        }else if(preference.getKey().equals("contact_global_bg_status_mod_picker")){
            EhsanMods.getShowColor(this,"contact_global_bg_status_mod_picker", Color.BLACK);

        }

        return EhsanMods.isRestart= true;
    }

    SharedPreferences.OnSharedPreferenceChangeListener check = new SharedPreferences.OnSharedPreferenceChangeListener(){
        public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            if(!key.equals("selectable_text_off_check")
                    && !key.equals("bubble_style")
                    && !key.equals("size_left_message_text_color_picker")
                    && !key.equals("size_date_message_text_color_picker")
                    && !key.equals("status_toast_check")
                    && !key.equals("emoji_hide_plus_tab_check")
                    && !key.equals("chat_disable_sensor_action_check")
                    && !key.equals("open_keyboard_check")
                    && !key.equals("hide_contact_global_status_check")
                    && !key.equals("chat_stock_emoji_size_check")
                    || !key.equals("chat_emoji_size_picker"));

            {
                EhsanMods.isRestart= true;
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(check);
    }



    @Override
    protected void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(check);

    }
}
