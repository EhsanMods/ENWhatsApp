package re.ehsan.plus;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import de.devmil.common.ui.Color.ColorSelectorDialog;

/**
 * Created by Mr_ehsan on 26/10/15.
 */
public class ChatTransparent extends PreferenceActivity implements Preference.OnPreferenceClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_chat_transparent", "xml"));
        EhsanMods.setToast("For Lollipop", this);
        PrefKeys();
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void PrefKeys(){
        findPreference("chat_transparent_mode_sb_color_picker").setOnPreferenceClickListener(this);
        findPreference("chat_transparent_mode_nav_color_picker").setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference.getKey().equals("chat_transparent_mode_sb_color_picker")) {
            EhsanMods.getShowColor(this,"chat_transparent_mode_sb_color_picker", Color.BLACK);

        }else if(preference.getKey().equals("chat_transparent_mode_nav_color_picker")){
            EhsanMods.getShowColor(this, "chat_transparent_mode_nav_color_picker", Color.WHITE);

            }

        return EhsanMods.isRestart =true;
    }
}
