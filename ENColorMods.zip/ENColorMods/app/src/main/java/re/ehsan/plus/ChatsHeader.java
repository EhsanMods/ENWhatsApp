package re.ehsan.plus;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by Mr_ehsan on 12/11/15.
 */
public class ChatsHeader extends PreferenceActivity implements Preference.OnPreferenceClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_chats_header", "xml"));
        PrefKeys();
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void PrefKeys(){
        findPreference("header_background_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_header_icons_color_picker").setOnPreferenceClickListener(this);
        findPreference("pagetitle_picker").setOnPreferenceClickListener(this);
        findPreference("pagetitle_sel_picker").setOnPreferenceClickListener(this);
        findPreference("msg_badge_picker").setOnPreferenceClickListener(this);
        findPreference("title_badgebg_picker").setOnPreferenceClickListener(this);
        findPreference("tabindicator_color_picker").setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference){
        if (preference.getKey().equals("header_background_color_picker")) {
            EhsanMods.getShowColor(this,"header_background_color_picker", 0xff0000ff);

        } else if (preference.getKey().equals("chats_header_icons_color_picker")) {
            EhsanMods.getShowColor(this, "chats_header_icons_color_picker",Color.CYAN);

        } else if (preference.getKey().equals("pagetitle_picker")) {
            EhsanMods.getShowColor(this, "pagetitle_picker",Color.CYAN);

        }else if (preference.getKey().equals("pagetitle_sel_picker")) {
            EhsanMods.getShowColor(this, "pagetitle_sel_picker", Color.BLUE);

        }else if (preference.getKey().equals("msg_badge_picker")) {
            EhsanMods.getShowColor(this, "msg_badge_picker",0xFF075E54);

        }else if (preference.getKey().equals("title_badgebg_picker")) {
            EhsanMods.getShowColor(this,"title_badgebg_picker", Color.GREEN);

        }else if (preference.getKey().equals("tabindicator_color_picker")) {
            EhsanMods.getShowColor(this,"tabindicator_color_picker", 0xFF075E54);
        }

        return EhsanMods.isRestart= true;
        }



    SharedPreferences.OnSharedPreferenceChangeListener check = new SharedPreferences.OnSharedPreferenceChangeListener(){
        public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            if(!key.equals("chats_show_my_name_check"));

            {
               EhsanMods.isRestart= true;
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(check);
    }



    @Override
    protected void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(check);

    }

    }


