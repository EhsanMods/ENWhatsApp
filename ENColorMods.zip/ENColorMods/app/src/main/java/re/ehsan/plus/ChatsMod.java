package re.ehsan.plus;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by Mr_ehsan on 12/11/15.
 */
public class ChatsMod extends PreferenceActivity implements Preference.OnPreferenceClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_chats_mod", "xml"));
        PrefKeys();
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void PrefKeys(){
        findPreference("chats_bg_odd_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_contacts_names_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_contacts_group_names_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_date_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_date_pending_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_msg_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_msg2_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_unread_msg_bg_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_unread_msg_text_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_from_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_row_divider_picker").setOnPreferenceClickListener(this);
        findPreference("chats_mute_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_cam_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_video_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_audio_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_mic_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_mic_play_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_Location_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("status_color2_picker").setOnPreferenceClickListener(this);
        findPreference("status_read_color2_picker").setOnPreferenceClickListener(this);
        findPreference("typing_color_chats_picker").setOnPreferenceClickListener(this);
        findPreference("is_recording_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_status_text_color_picker").setOnPreferenceClickListener(this);
        findPreference("chats_status_online_text_color_picker").setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference){
        if (preference.getKey().equals("chats_bg_odd_color_picker")) {
            EhsanMods.getShowColor(this,"chats_bg_odd_color_picker", 0xff0000ff);

        } else if (preference.getKey().equals("chats_contacts_names_color_picker")) {
            EhsanMods.getShowColor(this, "chats_contacts_names_color_picker", Color.CYAN);

        } else if (preference.getKey().equals("chats_contacts_group_names_color_picker")) {
            EhsanMods.getShowColor(this, "chats_contacts_group_names_color_picker",Color.CYAN);

        }else if (preference.getKey().equals("chats_date_color_picker")) {
            EhsanMods.getShowColor(this, "chats_date_color_picker", Color.BLUE);

        }else if (preference.getKey().equals("chats_date_pending_color_picker")) {
            EhsanMods.getShowColor(this, "chats_date_pending_color_picker",0xFF075E54);

        }else if (preference.getKey().equals("chats_msg_color_picker")) {
            EhsanMods.getShowColor(this,"chats_msg_color_picker", Color.GREEN);

        }else if (preference.getKey().equals("chats_msg2_color_picker")) {
            EhsanMods.getShowColor(this,"chats_msg2_color_picker", 0xFF075E54);

        }else if (preference.getKey().equals("chats_unread_msg_bg_color_picker")) {
            EhsanMods.getShowColor(this,"chats_unread_msg_bg_color_picker", 0xFF075E54);

        }else if (preference.getKey().equals("chats_unread_msg_text_color_picker")) {
            EhsanMods.getShowColor(this,"chats_unread_msg_text_color_picker", 0xFF075E54);
        }
        else if (preference.getKey().equals("chats_from_color_picker")) {
            EhsanMods.getShowColor(this,"chats_from_color_picker", 0xFF075E54);
        }
        else if (preference.getKey().equals("chats_row_divider_picker")) {
            EhsanMods.getShowColor(this,"chats_row_divider_picker", 0xFF075E54);
        }
        else if (preference.getKey().equals("chats_mute_icon_color_picker")) {
            EhsanMods.getShowColor(this,"chats_mute_icon_color_picker", 0xFF075E54);
        }
        else if (preference.getKey().equals("chats_cam_icon_color_picker")) {
            EhsanMods.getShowColor(this,"chats_cam_icon_color_picker", 0xFF075E54);
        }
        else if (preference.getKey().equals("chats_video_icon_color_picker")) {
            EhsanMods.getShowColor(this,"chats_video_icon_color_picker", 0xFF075E54);
        }
        else if (preference.getKey().equals("chats_audio_icon_color_picker")) {
            EhsanMods.getShowColor(this,"chats_audio_icon_color_picker", 0xFF075E54);
        }
        else if (preference.getKey().equals("chats_mic_icon_color_picker")) {
            EhsanMods.getShowColor(this,"chats_mic_icon_color_picker", 0xFF075E54);
        }
        else if (preference.getKey().equals("chats_mic_play_icon_color_picker")) {
            EhsanMods.getShowColor(this,"chats_mic_play_icon_color_picker", 0xFF075E54);
        }
        else if (preference.getKey().equals("chats_Location_icon_color_picker")) {
            EhsanMods.getShowColor(this,"chats_Location_icon_color_picker", 0xFF075E54);
        }
        else if (preference.getKey().equals("status_color2_picker")) {
            EhsanMods.getShowColor(this,"status_color2_picker", Color.GRAY);
        }
        else if (preference.getKey().equals("status_read_color2_picker")) {
            EhsanMods.getShowColor(this,"status_read_color2_picker", 0xFF075E54);

        }else if (preference.getKey().equals("typing_color_chats_picker")) {
            EhsanMods.getShowColor(this,"typing_color_chats_picker", 0xFF075E54);
        }

        else if (preference.getKey().equals("is_recording_color_picker")) {
            EhsanMods.getShowColor(this,"is_recording_color_picker", 0xFF075E54);
        }

        else if (preference.getKey().equals("chats_status_text_color_picker")) {
            EhsanMods.getShowColor(this,"chats_status_text_color_picker", EhsanMods.defColor);
        }

        else if (preference.getKey().equals("chats_status_online_text_color_picker")) {
            EhsanMods.getShowColor(this,"chats_status_online_text_color_picker", EhsanMods.defColor);
        }

        return EhsanMods.isRestart= true;
    }



    SharedPreferences.OnSharedPreferenceChangeListener check = new SharedPreferences.OnSharedPreferenceChangeListener(){
        public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            if(!key.equals("status_chats_check")
                    && !key.equals("conversations_bg_size_check")
                    && !key.equals("conversations_bg_size_picker")
                    && !key.equals("conversations_contacts_names_size_picker")
                    && !key.equals("conversations_date_size_picker")
                    && !key.equals("conversations_msg_size_picker")
                    && !key.equals("chats_hide_divider_check")
                    || !key.equals("chats_hide_archived_chats_footer_check"));

            {
                EhsanMods.isRestart= true;
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(check);
    }



    @Override
    protected void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(check);

    }
}
