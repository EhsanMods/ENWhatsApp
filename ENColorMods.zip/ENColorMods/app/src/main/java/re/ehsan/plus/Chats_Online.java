package re.ehsan.plus;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by Mr_ehsan on 12/11/15.
 */
public class Chats_Online extends PreferenceActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_chats_online", "xml"));
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    SharedPreferences.OnSharedPreferenceChangeListener check = new SharedPreferences.OnSharedPreferenceChangeListener(){
        public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            if(!key.equals("chats_show_contact_online_toast_check")
                    || !key.equals("chats_play_contact_online_tone"));

            {
                EhsanMods.isRestart= true;
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(check);
    }



    @Override
    protected void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(check);

    }
}
