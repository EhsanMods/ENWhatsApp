package re.ehsan.plus;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.TypefaceSpan;
import android.text.util.Linkify;
import android.util.Log;
import android.util.StateSet;
import android.util.TypedValue;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EdgeEffect;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.enwhatsapp.I;
import com.enwhatsapp.TextEmojiLabel;
import com.enwhatsapp.cy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

import de.devmil.common.ui.Color.ColorSelectorDialog;

import static android.graphics.PorterDuff.Mode.SRC_ATOP;


/**
 * Created by Mr_ehsan on 19/10/15.
 */
public class EhsanMods extends Object {

    final static public String PREFS_NAME = "com.enwhatsapp_en";
    final static private String PREF_KEY_SHORTCUT_ADDED = "App_Shortcut_Added";
    private static final String TAG = "EhsanMods";
    public static Context context;
    public static Context ctx;
    public static Activity EhsanModsActivity;
    public static boolean isRestart = false;
    public static Handler applicationHandler;
    public static final int defColor = 0xff58BCD5;//0xff43C3DB;//0xff2f8cc9;58BCD5//0xff55abd2
    public static float density = 1;

    public static void init(Context ctx) {
        Log.d(TAG, "Initializing context var..");
        if (ctx instanceof Activity) {
            EhsanMods.context = ((Activity) ctx)
                    .getApplicationContext();
        } else {
            EhsanMods.context = ctx;
        }
        if (EhsanMods.context == null)
            Log.d(TAG, "Context var initialized to NULL!!!");
        EhsanMods.setEhsanModsDefault(context);
    }

    public static void setEhsanModsActivity(Activity a){
        EhsanModsActivity = a;
    }

    public static int dp(float value) {
        return (int)Math.ceil(density * value);
    }

    public static float dpf2(float value) {
        return density * value;
    }


    public static void setListViewEdgeEffectColor(AbsListView listView, int color) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Field field = AbsListView.class.getDeclaredField("mEdgeGlowTop");
                field.setAccessible(true);
                EdgeEffect mEdgeGlowTop = (EdgeEffect) field.get(listView);
                if (mEdgeGlowTop != null) {
                    mEdgeGlowTop.setColor(color);
                }

                field = AbsListView.class.getDeclaredField("mEdgeGlowBottom");
                field.setAccessible(true);
                EdgeEffect mEdgeGlowBottom = (EdgeEffect) field.get(listView);
                if (mEdgeGlowBottom != null) {
                    mEdgeGlowBottom.setColor(color);
                }
            } catch (Exception e) {
            }
        }
    }


    public static void RestartApp(){
        android.os.Process.killProcess(android.os.Process.myPid());
    }
    public static void ResetEhsanMods(Context ctx){
        SharedPreferences themePrefs = ctx.getSharedPreferences(EhsanMods.PREFS_NAME, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = themePrefs.edit();
        editor.clear();
        editor.commit();
        //Stock Background
        SharedPreferences preferences = ctx.getSharedPreferences("com.enwhatsapp_preferences", Activity.MODE_PRIVATE);
        editor = preferences.edit();
        editor.commit();
        File toFile = new File(ctx.getFilesDir(), "wallpaper.jpg");
        if (toFile.exists()) {
            toFile.delete();
        }

    }
/*
    public static int getIntColor(String key){
        SharedPreferences themePrefs = context.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE);
        return themePrefs.getInt(key, defColor);
    }*/

    public static  void getShowColor(final Context ctx , final String str, int vld){
        final SharedPreferences themePrefs = ctx.getSharedPreferences(EhsanMods.PREFS_NAME, Activity.MODE_PRIVATE);
        ColorSelectorDialog dlg = new ColorSelectorDialog(ctx,
                new ColorSelectorDialog.OnColorChangedListener() {
                    public void colorChanged(int color) {
                        themePrefs.edit().putInt(str, color).apply();
                    }
                }, themePrefs.getInt(str, vld));
        dlg.show();
    }

    public static void showKeyboard(View view) {
        if (view == null) {
            return;
        }
        InputMethodManager inputManager = (InputMethodManager)view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);

        ((InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(view, 0);
    }

    public static boolean isKeyboardShowed(View view) {
        if (view == null) {
            return false;
        }
        InputMethodManager inputManager = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        return inputManager.isActive(view);
    }

    public static void hideKeyboard(View view) {
        if (view == null) {
            return;
        }
        InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (!imm.isActive()) {
            return;
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }


    public static int getIntDef(String key, int def){
        SharedPreferences themePrefs = context.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE);
        return themePrefs.getInt(key, def);
    }


    public static int getIntAlphaColor(String key, float factor){
        SharedPreferences themePrefs = context.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE);
        int color = themePrefs.getInt(key, defColor);
        int alpha = Math.round(Color.alpha(color) * factor);
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        return Color.argb(alpha, red, green, blue);
    }

    public static int getIntDarkerColor(String key, int factor){
        SharedPreferences themePrefs = context.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE);
        int color = themePrefs.getInt(key, defColor);
        return setDarkColor(color, factor);
    }

    public static int setDarkColor(int color, int factor){
        int red = Color.red(color) - factor;
        int green = Color.green(color) - factor;
        int blue = Color.blue(color) - factor;
        if(factor < 0){
            red = (red > 0xff) ? 0xff : red;
            green = (green > 0xff) ? 0xff : green;
            blue = (blue > 0xff) ? 0xff : blue;
            if(red == 0xff && green == 0xff && blue == 0xff){
                red = factor;
                green = factor;
                blue = factor;
            }
        }
        if(factor > 0){
            red = (red < 0) ? 0 : red;
            green = (green < 0) ? 0 : green;
            blue = (blue < 0) ? 0 : blue;
            if(red == 0 && green == 0 && blue == 0){
                red = factor;
                green = factor;
                blue = factor;
            }
        }
        return Color.argb(0xff, red, green, blue);
    }

    public static void setIntColor(String key, int value){
        SharedPreferences themePrefs = context.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE);
        SharedPreferences.Editor e = themePrefs.edit();
        e.putInt(key, value);
        e.commit();
    }

    public static void setBoolPref(Context context, String key, Boolean b){
        SharedPreferences sharedPref = context.getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor e = sharedPref.edit();
        e.putBoolean(key, b);
        e.commit();
    }

    public static boolean getBoolPref(Context context,String key){
        boolean s = false;
        if (context.getSharedPreferences(PREFS_NAME, 0).getBoolean(key, false)) s=true;
        return s;
    }

    public static boolean getBoolMain(String key){
        boolean s = false;
        if (context.getSharedPreferences("com.enwhatsapp_preferences", Activity.MODE_PRIVATE).getBoolean(key, false)) s=true;
        return s;
    }

    public static int getIntPref(Context context,String key){
        int i=0;
        if(key.contains("picker")){
            int intColor = context.getSharedPreferences(PREFS_NAME, 0).getInt(key, Color.WHITE );
            i=intColor;
        }
        return i;
    }

    public static int getIntColorDef(Context context, String key, int def) {
        int i = def;
        if (context.getSharedPreferences(PREFS_NAME, 0).getBoolean(key, false)) {
            i = context.getSharedPreferences(PREFS_NAME, 0).getInt(key.replace("_check", "_picker"), def);
        }
        return i;
    }

    public static void setTVTextColor(Context ctx, TextView tv, String key, int def){
        if(tv==null)return;
        if(getBoolPref(ctx, key))
            def = getIntPref(ctx, key.replace("_check", "_picker"));
        tv.setTextColor(def);
    }

    public static int getSizePref(Context context,String key, int def){
        if(key.contains("picker"))return context.getSharedPreferences(PREFS_NAME, 0).getInt(key, def);
        return def;
    }

    public static void paintActionBarHeader(Activity a, ActionBar ab, String hdCheck, String gdMode){
        if(ab==null)return;
        ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#54759E")));
        if(getBoolPref(a, hdCheck)){
            int i = getIntPref(a, hdCheck.replace("_check", "_picker"));
            Drawable d = new ColorDrawable(i);
            try{
                ab.setBackgroundDrawable(d);
                d = paintGradient(a,i,gdMode.replace("mode","color_picker"),gdMode);
                if(d!=null)ab.setBackgroundDrawable(d);
            } catch (Exception e) {
                Log.e(TAG, e.toString());
            }
        }
    }

    public static Drawable paintGradient(Context c, int mainColor, String gColor, String g){
        GradientDrawable gd = null;
        int[] a ={mainColor,getIntPref(c,gColor)};
        int gType = Integer.parseInt(c.getSharedPreferences(PREFS_NAME, 0).getString(g, "0"));
        if(gType==2) gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,a);
        if(gType==1) gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM ,a);
        return gd;
    }

    public static Drawable paintDrawable(Context c, int resId, int resIdW, String color){
        Drawable d = c.getResources().getDrawable(resId);
        if(color.contains("_check")){
            if(getBoolPref(c, color)){
                d = c.getResources().getDrawable(resIdW);
                d.setColorFilter(getIntPref(c, color.replace("_check", "_picker")), PorterDuff.Mode.MULTIPLY);
            }
        }
        return d;
    }
    public static int loadPrefFromSD(Context context, String prefPath){
        File dataF = new File (findPrefFolder(context), PREFS_NAME + ".xml");
        File prefFile = new File (prefPath);
        String s = getError(copyFile(prefFile, dataF, false));
        if (s.contains("0")) {
            Toast.makeText(context,"ERROR: "+ context.getString(EhsanMods.getResId(context, "restoreErrorMsg", "string"), prefFile.getAbsolutePath()) , Toast.LENGTH_LONG ).show();
        }
        return Integer.parseInt(s);
    }

    public static int loadWallpaperFromSDPath(Context context, String wPath){
        String nFile = "wallpaper.jpg";
        File f1 = context.getFilesDir();
        f1= new File (f1.getAbsolutePath(), nFile);
        //Log.i("f1", f1.getAbsolutePath());
        File wFile = new File (wPath);
        //Log.i("wPath", wPath);
        //Log.i("wFile", wFile.getAbsolutePath());
        String s = "-1";
        if (wFile.exists()){
            s = getError(copyFile(wFile,f1,false));
            if (s.contains("0")) {
                Toast.makeText(context,"ERROR: "+ context.getString(EhsanMods.getResId(context, "restoreErrorMsg", "string"),wFile.getAbsolutePath()) ,Toast.LENGTH_LONG ).show();
            }else{
                Toast.makeText(context,"ERROR: "+s+"\n"+wFile.getAbsolutePath(),Toast.LENGTH_LONG ).show();
            }
        }
        return Integer.parseInt(s);
    }
        static void modifyXMLfile(File preffile,String sname){
            try {
                File file = preffile;
                //Log.e("modifyXMLfile",preffile.getAbsolutePath());
                //Log.e("modifyXMLfile",preffile.exists()+"");
                List<String> lines = new ArrayList<String>();
                // first, read the file and store the changes
                BufferedReader in = new BufferedReader(new FileReader(file));
                String line = in.readLine();
                while (line != null) {
                    if (!line.contains(sname))lines.add(line);
                    //Log.e("modifyXMLfile",line);
                    line = in.readLine();
                }
                in.close();
                // now, write the file again with the changes
                PrintWriter out = new PrintWriter(file);
                for (String l : lines)
                    out.println(l);
                out.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    public static void ShowMyName(ActionBar acb,Context ctx){
        if(EhsanMods.getBool(ctx, "chats_show_my_name_check")){
            acb.setTitle(t.a(App.b(ctx), ctx));
        }else{
            acb.setTitle("ENWhatsApp");
        }
    }

    public static void AutoUpdate(Activity auto){

        WVersionManager versionManager = new WVersionManager(auto);
        versionManager.setVersionContentUrl(EhsanMods.getString("Ehsan_Url_Update", auto));
        versionManager.setUpdateNowLabel(EhsanMods.getString("Ehsan_Now_Update", auto));
        versionManager.setRemindMeLaterLabel(EhsanMods.getString("Ehsan_Later_Update", auto));
        versionManager.setIgnoreThisVersionLabel(EhsanMods.getString("Ehsan_Ignore_Update", auto));
        versionManager.setUpdateUrl("http://www.ehsan.re");
        versionManager.setReminderTimer(1);
        versionManager.checkVersion();
        //Changlog
        ChangeLog cl = new ChangeLog(auto);
        if (cl.firstRun()) {
            cl.getLogDialog().show();
            return;

        }

    }


    public static void setActionView(String text,Activity view){
        Intent i= new Intent("android.intent.action.VIEW", Uri.parse(text));
        view.startActivity(i);

    }

    public static void setEhsanModsDefault(Context ctx){

    }

    public static void getPreviewVideo(final String url, final Context ctx) {
        CharSequence option[] = new CharSequence[] {EhsanMods.getString("Ehsan_View", ctx), EhsanMods.getString("Ehsan_Share", ctx), EhsanMods.getString("Ehsan_Copy", ctx)};

        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setItems(option, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        Intent intent= new Intent("android.intent.action.VIEW");
                        intent.setDataAndType(Uri.parse(url), "video/*");
                        ctx.startActivity(intent);
                        break;
                    case 1:
                        EhsanMods.getShare(ctx, EhsanMods.getString("app_name", ctx), String.valueOf(Uri.parse(url)), EhsanMods.getString("ENShare", ctx));
                        break;
                    case 2:
                        EhsanMods.setCopy(ctx, String.valueOf(Uri.parse(url)));
                        break;
                    default:
                        break;
                }

            }
        });
        builder.show();

    }

    public static void getPreviewImg(final String url, final Context ctx) {
        CharSequence option[] = new CharSequence[] {EhsanMods.getString("Ehsan_View", ctx), EhsanMods.getString("Ehsan_Share", ctx), EhsanMods.getString("Ehsan_Copy", ctx)};

        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setItems(option, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        Intent img = new Intent(ctx, Other.class);
                        img.putExtra("url", url);
                        ctx.startActivity(img);
                        break;
                    case 1:
                        EhsanMods.getShare(ctx, EhsanMods.getString("app_name", ctx), String.valueOf(Uri.parse(url)), EhsanMods.getString("ENShare", ctx));

                        break;
                    case 2:
                        EhsanMods.setCopy(ctx, String.valueOf(Uri.parse(url)));
                        break;
                    default:
                        break;
                }

            }
        });
        builder.show();

    }

    public static void copyWallpaperToSD(Context context, String tName, boolean toast){
        String folder = "/ENWhatsApp/Themes";
        String nFile = "wallpaper.jpg";
        if(checkSDStatus()>0){
            File f1 = context.getFilesDir();
            f1 = new File (f1.getAbsolutePath(), nFile);
            File f2 = new File (Environment.getExternalStorageDirectory(), folder);
            f2.mkdirs();
            f2 = new File(f2, tName+"_"+nFile);
            if(f1.length()>1){
                String s = getError(copyFile(f1,f2,true));
                if(s.contains("4")){
                    if(toast && f2.getName()!="" && folder !="")Toast.makeText(context,context.getString(EhsanMods.getResId(context, "SavedTo", "string"),f2.getName(),folder),Toast.LENGTH_SHORT ).show();
                    if(f2.getName()=="" || folder =="") Toast.makeText(context,"ERROR: "+s,Toast.LENGTH_SHORT ).show();

                }else{
                    Toast.makeText(context,"ERROR: "+s+"\n"+f1.getAbsolutePath(),Toast.LENGTH_LONG ).show();
                }
            }
        }
    }

    static String findPrefFolder(Context context){
        File f = context.getFilesDir();
        String appDir = f.getAbsolutePath();
        File SPDir = new File (appDir.substring(0,appDir.lastIndexOf('/')+1)+ "shared_prefs/");
        if(!SPDir.exists()) {// && SPDir.isDirectory()) {
            String pck = context.getPackageName();
            SPDir=new File ("/dbdata/databases/"+pck+"/shared_prefs/");
        }
        //Log.i("TAG", SPDir.getAbsolutePath());
        return SPDir.getAbsolutePath();
    }

    static int checkSDStatus(){
        int b=0;
        String s = Environment.getExternalStorageState();
        if (s.equals(Environment.MEDIA_MOUNTED))b=2;
        else if (s.equals(Environment.MEDIA_MOUNTED_READ_ONLY))b=1;
        return b;
    }

    static String getError(int i){
        String s="-1";
        if(i==0)s="0: SOURCE FILE DOESN'T EXIST";
        if(i==1)s="1: DESTINATION FILE DOESN'T EXIST";
        if(i==2)s="2: NULL SOURCE & DESTINATION FILES";
        if(i==3)s="3: NULL SOURCE FILE";
        if(i==4)s="4";
        return s;
    }


    static int copyFile(File sourceFile, File destFile, boolean save) {
        int i=-1;
        try{
            if (!sourceFile.exists()) {
                return i+1;
            }
            if (!destFile.exists()) {
                if(save)i=i+2;
                destFile.createNewFile();
            }
            FileChannel source = null;
            FileChannel destination = null;
            FileInputStream fileInputStream = new FileInputStream(sourceFile);
            source = fileInputStream.getChannel();
            FileOutputStream fileOutputStream = new FileOutputStream(destFile);
            destination = fileOutputStream.getChannel();
            if (destination != null && source != null) {
                destination.transferFrom(source, 0, source.size());
                i=2;
            }
            if (source != null) {
                source.close();
                i=3;
            }
            if (destination != null) {
                destination.close();
                i=4;
            }
            fileInputStream.close();
            fileOutputStream.close();
        }catch (Exception e)
        {
            System.err.println("Error saving preferences: " + e.getMessage());
            Log.e(e.getMessage() , e.toString());
        }
        return i;
    }

    public static void savePreferencesToSD(Context context, String prefName, String tName, boolean toast){
        String folder = "/ENWhatsApp/Themes";
        File dataF = new File (findPrefFolder(context),prefName);
        if(checkSDStatus() > 1){
            File f = new File (Environment.getExternalStorageDirectory(), folder);
            f.mkdirs();
            File sdF = new File(f, tName);
            String s = getError(copyFile(dataF,sdF,true));
            if (s.equalsIgnoreCase("4")) {
                if(toast && sdF.getName()!="")Toast.makeText(context,context.getString(EhsanMods.getResId(context, "SavedTo", "string"),sdF.getName(),folder),Toast.LENGTH_SHORT ).show();
            }else if (s.contains("0")) {
                s = context.getString(EhsanMods.getResId(context, "SaveErrorMsg0", "string"));
                Toast.makeText(context,"ERROR: "+ s ,Toast.LENGTH_LONG ).show();
            }else{
                Toast.makeText(context,"ERROR: "+s,Toast.LENGTH_LONG ).show();
                Toast.makeText(context,dataF.getAbsolutePath(),Toast.LENGTH_LONG ).show();
            }
        }else{
            Toast.makeText(context,"ERROR: " + context.getString(EhsanMods.getResId(context, "NoMediaMessage", "string")) , Toast.LENGTH_LONG).show();
        }
    }

    public static void runOnUIThread(Runnable runnable) {
        runOnUIThread(runnable, 0);
    }

    public static void runOnUIThread(Runnable runnable, long delay) {
        if (delay == 0) {
            EhsanMods.applicationHandler.post(runnable);
        } else {
            EhsanMods.applicationHandler.postDelayed(runnable, delay);
        }
    }

    public static void cancelRunOnUIThread(Runnable runnable) {
        EhsanMods.applicationHandler.removeCallbacks(runnable);
    }



    public static void getSaveTheme(final Context ctx){
        LayoutInflater li = LayoutInflater.from(ctx);
        View promptsView = li.inflate(EhsanMods.getResId(ctx, "editbox_dialog", "layout"), null);
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setView(promptsView);
        final EditText userInput = (EditText) promptsView.findViewById(EhsanMods.getResId(ctx, "editTextDialogUserInput", "id"));
        builder.setMessage(EhsanMods.getResId(ctx, "EnterName", "string"));
        builder.setTitle(EhsanMods.getResId(ctx, "SaveTheme", "string"));
        builder.setPositiveButton(EhsanMods.getResId(ctx, "EN_OK", "string"), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String pName = userInput.getText().toString();
                EhsanMods.setStringPref(ctx, "themeName", pName);
                EhsanMods.savePreferencesToSD(ctx, EhsanMods.PREFS_NAME + ".xml", pName + ".xml", true);
                EhsanMods.copyWallpaperToSD(ctx, pName, true);
                Toast toast = Toast.makeText(ctx, EhsanMods.getResId(ctx, "SaveThemeToastText", "string"), Toast.LENGTH_SHORT);
                toast.show();
            }
        });
        builder.setNegativeButton(EhsanMods.getResId(ctx, "EN_Cancel", "string"), null);
        builder.show();
    }


    public static void setStringPref(Context context, String key, String s){
        SharedPreferences sharedPref = context.getSharedPreferences("com.enwhatsapp_en", 0);
        SharedPreferences.Editor e = sharedPref.edit();
        e.putString(key, s);
        e.commit();
    }

    public static void setCopy(Context ctx, String str){
        android.text.ClipboardManager clipboard = (android.text.ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setText(str);
        Toast.makeText(ctx, EhsanMods.getString("Ehsan_Copy_done", ctx), Toast.LENGTH_SHORT).show();
    }

    public static boolean isOnline(Context ctx) {
        if (ctx == null)
            return false;
        ConnectivityManager cm =
                (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        }
        EhsanMods.setToast("Check Internet", ctx);
        return false;
    }

    public static void setActionView(String text,Context ctx){
        Intent i= new Intent("android.intent.action.VIEW", Uri.parse(text));
        ctx.startActivity(i);

    }
    public static void setClassActivity(String clas,Context ctx){
        Intent i = new Intent(clas);
        ctx.startActivity(i);
    }

    public static void setClassActivity(String clas,Activity encon){
        Intent i = new Intent(clas);
        encon.startActivity(i);
    }

    public static void setToast(String text){
        Toast.makeText(context, text, Toast.LENGTH_LONG).show();
    }

    public static void setToast(String text, Context af){
        Toast.makeText(af, text, Toast.LENGTH_LONG).show();
    }


    public static int getResId(Context context, String s1, String s2) {
        return context.getResources().getIdentifier(s1, s2, context.getPackageName());
    }

    public static int getResID(String name, String Type, Context context){
        return context.getResources().getIdentifier(name, Type, context.getPackageName());
    }

    public static String getString(String paramString, Context context){
        return context.getString(context.getResources().getIdentifier(paramString, "string", context.getPackageName()));
    }

    public static boolean getBool(Context context, String name){
        return context.getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE | Context.MODE_MULTI_PROCESS).getBoolean(name, false);
    }

    public static int getIntfromKey(Context ctx, String str){
        return ctx.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE).getInt(str, 30);
    }

    public static int getIntfromkey(String key){
        return context.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE).getInt(key, 30);

    }

    public static void getShare (Context ctx, String sbj, String bdy, String via){
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, sbj);
        i.putExtra(Intent.EXTRA_TEXT, bdy);
        ctx.startActivity(Intent.createChooser(i, via));
    }

    public static void getShareXML_IMG (Context ctx,File xml,File img){
        Intent i = new Intent(Intent.ACTION_SEND_MULTIPLE);
        i.setType("text/xml");
        i.setType("image/jpeg");
        i.putExtra(Intent.EXTRA_TEXT, xml);
        i.putExtra(Intent.EXTRA_STREAM, img);
        ctx.startActivity(Intent.createChooser(i, "Share Theme !"));
    }

    public static void getShareTheme (Context ctx){
        String folder = "/ENWhatsApp/Themes";
        String nFile = "en_wallpaper.jpg";
        String xFile = "com.enwhatsapp_en.xml";
        File f = new File (Environment.getExternalStorageDirectory(), folder + nFile);
        File a = new File (Environment.getExternalStorageDirectory(), folder + xFile);
        EhsanMods.setStringPref(ctx, "themeName", "com.enwhatsapp_en");
        EhsanMods.savePreferencesToSD(ctx, EhsanMods.PREFS_NAME + ".xml", "com.enwhatsapp_en" + ".xml", true);
        EhsanMods.copyWallpaperToSD(ctx, "en_wallpaper", true);
        EhsanMods.getShareXML_IMG(ctx, a, f);
    }

    public static void ClearLogs(Context ctx){
        File DataLogs = new File(ctx.getFilesDir(), "/Logs");
        deleteFile(DataLogs);
        EhsanMods.setToast(EhsanMods.getString("Ehsan_Done", ctx), ctx);
    }

    public static void deleteFile(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            for (File sub : fileOrDirectory.listFiles()) {
                deleteFile(sub);
            }
        }
        fileOrDirectory.delete();
    }

    public static int GetPrefsIconApp(Context cm) {
        return Integer.parseInt(cm.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE).getString("en_icons", "0"));
    }

    public static Drawable getDrawableColor (Context v,String str, int cr, int i) {
        Drawable d = v.getResources().getDrawable(i);
        d.setColorFilter(new
                PorterDuffColorFilter(EhsanMods.getIntDef(str, cr), PorterDuff.Mode.SRC_ATOP));
        return d;
    }

    public static Drawable getDrawableColorSI (Context v,String str, int cr, int i) {
        Drawable d = v.getResources().getDrawable(i);
        d.setColorFilter(new
                PorterDuffColorFilter(EhsanMods.getIntDef(str, cr), PorterDuff.Mode.SRC_IN));
        return d;
    }

    public static int getIconApp(Activity EhsanModsActivity) {
        int  icon= EhsanMods.getResId(EhsanModsActivity, "en_icon_0", "drawable");
        try {
          GetPrefsIconApp(EhsanModsActivity);
            icon= EhsanModsActivity.getResources().getIdentifier("en_icon_"+icon, "drawable", EhsanModsActivity.getPackageName());
        }catch(Exception e){}
        return icon;
    }

    public static void ClickableLinks(TextView tv){
        Linkify.addLinks(tv, 1);
    }

    public static void setMinimumHeight(View view, String str) {
        view.getLayoutParams().height = getIntDef(str, -0);
    }

    public static void setStatusBarColor(Activity activity, View statusBar, int color) {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.KITKAT) {
            Window w = activity.getWindow();
            w.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            //status bar height
            int actionBarHeight = getActionBarHeight(activity);
            int statusBarHeight = getStatusBarHeight(activity);
            //action bar height
            statusBar.getLayoutParams().height = actionBarHeight + statusBarHeight + 10;
            statusBar.setBackgroundColor(color);
        }
    }

    public static int getActionBarHeight(Activity activity) {
        int actionBarHeight = 0;
        TypedValue tv = new TypedValue();
        if (activity.getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, activity.getResources().getDisplayMetrics());
        }
        return actionBarHeight;
    }

    public static int getStatusBarHeight(Activity activity) {
        int result = 0;
        int resourceId = activity.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = activity.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    /*
    * هنا مكان اكواد الوان
    * */

    // Color coeds start.

    public static void setColorViewCall(View v) {
        View  vi= v.findViewById(R.id.action_bar_subtitle);
        vi.setBackgroundColor(getIntDef("color_div_call_picker", -0));
    }

    public static void setColorBackCall(ListView lview) {
        lview.setDivider(new ColorDrawable(getIntDef("color_div_call_picker", -0)));
        if(getBool(context, "hide_div_call_check")) {
            lview.setDividerHeight(0x0);
        }else{
            lview.setDividerHeight(0x1);
        }
    }

    public static void setTextColorNameCall(TextView textview) {
        textview.setTextColor(getIntDef("color_name_call_picker",-0));
        textview.setTextSize((float) getIntPref(context, "size_name_call_picker"));
    }

    public static void setTextColorDateCall(TextView textview) {
        textview.setTextColor(getIntDef("color_date_call_picker",-0));
        textview.setTextSize((float) getIntPref(context, "size_date_call_picker"));
    }

    public static void setColorIconCall(View view) {
        ImageView  img= (ImageView) view.findViewById(R.id.action_bar_activity_content);
        img.setColorFilter(getIntDef("color_icon_call_picker", -0), SRC_ATOP);
    }

    public static void setCountCallColor(TextView tv) {
        tv.setTextColor(getIntDef("call_count_color_picker", -0));
    }

    public static void setNameColorChats(TextView tv) {
        tv.setTextColor(getIntDef("chats_contacts_names_color_picker",-0));
        tv.setTextSize((float) getIntPref(context, "conversations_contacts_names_size_picker"));
    }

    public static void setTextColorInvitContacts(TextView tv) {
        tv.setTextColor(getIntDef("contacts_invit_color_picker",-0));
        tv.setTextSize((float) getIntPref(context, "chats_contacts_names_color_picker"));
    }

    public static void setGroupNameColorChats(TextView tv) {
        tv.setTextColor(getIntDef("chats_contacts_group_names_color_picker",-0));
        tv.setTextSize((float)getIntPref(context, "conversations_contacts_names_size_picker"));
    }

    public static void setTextColorNameContacts(TextEmojiLabel tv) {
        tv.setTextColor(getIntDef("contacts_names_color_picker",-0));
        tv.setTextSize((float) getIntPref(context, "conversations_contacts_names_size_picker"));
    }

    public static void setDateReadColorChats(TextView tv) {
        tv.setTextColor(getIntDef("chats_date_color_picker", -0));
        tv.setTextSize((float) getIntPref(context, "conversations_date_size_picker"));
    }

    public static void setDateColorChats(TextView tv) {
        tv.setTextColor(getIntDef("chats_date_pending_color_picker", -0));
        tv.setTextSize((float) getIntPref(context, "conversations_date_size_picker"));
    }

    public static void setIconMsgColorChats(TextView tv) {
        tv.setBackgroundDrawable(getDrawableColor(context,"chats_unread_msg_bg_color_check", -0, R.drawable.abc_ab_share_pack_holo_dark));
        tv.setBackgroundResource(R.drawable.abc_ab_share_pack_holo_dark);
        tv.setTextColor(getIntPref(context, "chats_unread_msg_text_color_picker"));
    }

    public static void setMsgFromColorChats(TextView tv) {
        tv.setTextColor(getIntDef("chats_from_color_picker", -0));
        }

    public static void setColordividerChats(ListView lv){
        lv.setDivider(new ColorDrawable(getIntDef("chats_row_divider_picker", -0)));
        if (getBoolPref(context, "chats_hide_divider_check")) {
        lv.setDividerHeight(0x0);
        } else {
            lv.setDividerHeight(0x1);
        }
    }

    public static void setIconMuteColorChats(ImageView tv) {
        tv.setImageDrawable(getDrawableColor(context, "chats_mute_icon_color_picker", -0, R.drawable.abc_btn_check_material));
    }


    public static void setIconCamColorChats(ImageView tv, int mint) {
        tv.setImageDrawable(getDrawableColorSI(context, "chats_cam_icon_color_picker", -0, mint));

    }


    public static void setIconVideoColorChats(ImageView tv, int mint){
        tv.setImageDrawable(getDrawableColor(context, "chats_video_icon_color_picker", -0, mint));
    }

    public static void setIconAudioColorChats(ImageView tv, int mint){
        tv.setImageDrawable(getDrawableColor(context, "chats_audio_icon_color_picker", -0, mint));
    }

    public static void setIconMicColorChats(ImageView tv, int mint) {
        tv.setImageDrawable(getDrawableColor(context, "chats_mic_icon_color_picker", -0, mint));
    }

   public static void setIconNewMicColorChats(ImageView tv, int mint) {
       tv.setImageDrawable(getDrawableColor(context, "chats_mic_play_icon_color_picker", -0, mint));
   }

   public static void setIconLocationColorChats(ImageView tv, int mint) {
        tv.setImageDrawable(getDrawableColor(context, "chats_Location_icon_color_picker", -0, mint));
   }

   public static void setPaintStatusMsgChats(Drawable iv, int i) {
        String  KeyColorread= "status_read_color2_picker";
        String  KeyColorelse= "status_color2_picker";
        if(i==0x7f020878 && i==0x7f020870 && i == 0x7f02086f && i == 0x7f020586 || i == 0x7f020879) {
        iv.setColorFilter(getIntDef(KeyColorread,-0), PorterDuff.Mode.SRC_IN);}
        iv.setColorFilter(getIntDef(KeyColorelse, -0), PorterDuff.Mode.SRC_IN);
   }


    public static void setMsg2ColorChats(TextView tv) {
        tv.getText().toString().contains(context.getString(R.string.ApplyTheme));
        tv.setTextColor(getIntDef("typing_color_chats_picker",-0));
        tv.getText().toString().contains(context.getString(R.string.ApplyTheme));
        tv.setTextColor(getIntDef("is_recording_color_picker",-16711936));
        tv.getText().toString().contains(context.getString(R.string.ApplyTheme));
        tv.setTextColor(getIntDef("is_recording_color_picker", -16711936));
        tv.setTextColor(getIntDef("chats_msg2_color_picker",-0));
        tv.setTextSize((float) getIntPref(context, "conversations_msg_size_picker"));
  }

    public static void setTextIsSelectable(Context cm, TextEmojiLabel tel) {
        if(!getBoolPref(cm, "selectable_text_off_check") && Build.VERSION.SDK_INT >= 11) {
        tel.setTextIsSelectable(true);
            }
        }

     public static void setHideArchived(TextView tv, Context ctx) {
        if(getBool(ctx, "chats_hide_archived_chats_footer_check")) {
        tv.setVisibility(View.GONE);
        }else{
        tv.setVisibility(View.INVISIBLE);
         }
     } //endmet

    public static void setbackbarbtnchat(LinearLayout l){
        ImageView  iv= (ImageView) l.getChildAt(0x0);
        Drawable  d= iv.getDrawable();
        d.setColorFilter(getIntDef("chat_header_icons_color_picker",-0), PorterDuff.Mode.SRC_IN);
        iv.setImageDrawable(d);
        }

    public static void setColorNameBarChat(Activity a, TextView tv) {
        tv.setTextColor(getIntDef("contact_name_color_picker",-0));
        if (getBoolPref(a, "bold_names_check"))
        {
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        }
    }

   public static void setOnlineChatColor(TextView tv) {
        tv.getText().toString().contains(getString("conversation_contact_online", EhsanModsActivity));
        tv.setTextColor(getIntDef("online_color_picker",-0));
        tv.getText().toString().contains(getString("conversation_is_composing", context));
        tv.setTextColor(getIntDef("typing_color_picker", -0));
   }

    public static void setLastSeenChatColor(Context cm, TextView tv) {
       tv.getText().toString().contains(cm.getString(R.string.ApplyTheme));
        tv.setTextColor(getIntDef("online_color_picker", -0));
       tv.getText().toString().contains(cm.getString(R.string.ApplyTheme));
       tv.setTextColor(getIntDef("typing_color_picker", -0));
  }
//endmet

    public static void setbgClip(FrameLayout fl, Context cm) {
        fl.setBackgroundColor(getIntDef("chat_attach_bg_color_picker", -0));
  }

    public static void setPopupColor(Activity a) {
        if(Build.VERSION.SDK_INT >= 11) {
        a.findViewById(R.id.action_bar_activity_content).setBackgroundColor(getIntDef("popup_header_background_color_picker",-0));

        a.findViewById(R.id.action_bar_activity_content).setBackgroundColor(getIntDef("popup_background_color_picker",-0));

        a.findViewById(R.id.action_bar_activity_content).setBackgroundColor(getIntDef("popup_footer_background_color_picker",-0));
          }
   }


    public static void setEnterPopup(TextView tv) {
        tv.setTextColor(getIntDef("popup_text_entry_color_picker", -0));
        }

    public static void setTitlePopup(TextView tv) {
        tv.setTextColor(getIntDef("popup_title_color_picker",-0));
        }

    public static void setStatusPopup(TextView tv) {
        tv.setTextColor(getIntDef("popup_status_color_picker",-0));
    }


    public static void setCountPopup(Activity a, TextView tv) {
        tv.setTextColor(getIntDef("popup_counter_color_picker",-0));
    }

     public static void setOKBtnPopup(Activity a, Button btn) {
        btn.setTextColor(getIntDef("popup_buttons_text_color_picker",Color.WHITE));
   }



     public static int setColorNotifyLock() {
         return getIntDef("popup_locked_bg_color_picker", -0);
     }

    public static void setBtnSendPopup(Activity a, Drawable d) {
        d.setColorFilter(getIntDef("popup_send_icon_color_picker", -0), PorterDuff.Mode.MULTIPLY);
     }

    public static void setBtnMicPopup(Activity a, ImageButton iv) {
        Drawable d = a.getResources().getDrawable(R.drawable.abc_btn_radio_material);
        d.setColorFilter(getIntDef("popup_mic_icon_color_picker",-0), PorterDuff.Mode.MULTIPLY);
        iv.setImageDrawable(d);
    }

    public static int setLinkMsgChatColor() {
        return getIntDef("message_link_color_picker",-0);
        }

    public static void setRightMgTextColor(TextView tv) {
        tv.setTextColor(getIntDef("right_message_text_color_picker", Color.WHITE));
        tv.setTextSize((float) getIntPref(context, "size_left_message_text_color_picker"));
    }

    public static void setLeftMgTextColor(TextView tv) {
        tv.setTextColor(getIntDef("left_message_text_color_picker",Color.WHITE));
        tv.setTextSize((float) getIntPref(context, "size_left_message_text_color_picker"));
    }

    public static void setRightChatDateColor(TextView tv) {
        tv.setTextColor(getIntDef("date_right_color_picker",Color.WHITE));
        tv.setTextSize((float) getIntPref(context, "size_date_message_text_color_picker"));
    }

    public static void setLeftChatDateColor(TextView tv) {
        tv.setTextColor(getIntDef("date_color_picker", Color.WHITE));
        tv.setTextSize((float) getIntPref(context, "size_date_message_text_color_picker"));
    }

    public static void setDate_DivideChat(TextView tv,Drawable d) {
        tv.setTextColor(getIntDef("date_divider_color_picker",Color.WHITE));
        d.setColorFilter(getIntDef("date_bubble_color_picker", defColor), PorterDuff.Mode.SRC_IN);
        tv.setBackgroundDrawable(d);
    }

    public static void setDateDivideChat(TextView tv) {
        tv.setTextColor(getIntDef("date_divider_color_picker",Color.WHITE));
    }

    public static void setFromModChat(TextView tv, int i) {
        tv.setTextColor(getIntDef("participant_name_color_picker", -0));
        tv.setTextColor(i);
        }

    public static void setColorBtnEmoji(ImageButton iv, Activity a) {
        Drawable  d= a.getResources().getDrawable(R.drawable.abc_btn_switch_to_on_mtrl_00001);
        d.setColorFilter(getIntDef("emoji_icon_color_picker",-0), PorterDuff.Mode.SRC_IN);
        iv.setImageDrawable(d);
        }

    public static void setColorBtnSend(Drawable d) {
        d.setColorFilter(getIntDef("send_icon_color_picker", -0), PorterDuff.Mode.MULTIPLY);
    }

    public static void setColorBtnCam(ImageButton iv, Activity a) {
        Drawable  d= a.getResources().getDrawable(R.drawable.abc_ab_share_pack_holo_dark);
        d.setColorFilter(getIntDef("camera_icon_color_picker",-0), SRC_ATOP);
        iv.setImageDrawable(d);
    }

    public static void setColorBtnMic(ImageButton iv, Activity a) {
        Drawable  d= a.getResources().getDrawable(R.drawable.abc_ab_share_pack_holo_dark);
        d.setColorFilter(getIntDef("mic_icon_color_picker",-0), PorterDuff.Mode.MULTIPLY);
        iv.setImageDrawable(d);
        }
    public static void setColorBtnInput(Context a, View view) {
        Drawable  d= a.getResources().getDrawable(R.drawable.abc_ab_share_pack_holo_dark);
        d.setColorFilter(getIntDef("mic_circle_mod_picker",-0), SRC_ATOP);
        view.setBackgroundDrawable(d);
    }

    public static Drawable setTextEntryBgChat(int i, Context cm) {
        Drawable  d= cm.getResources().getDrawable(i);
        d.setColorFilter(getIntDef("text_entry_bg_color_picker", -0), PorterDuff.Mode.MULTIPLY);
        return d;
    }

    public static void setColorEmojiselected(Drawable d) {
        d.setColorFilter(getIntDef("emoji_selected_color_picker",-0), PorterDuff.Mode.SRC_IN);
    }

    public static void setColorEmojiselected(ImageView iv, ViewGroup v) {
        FrameLayout  f= (FrameLayout) v.findViewById(R.id.action_bar_activity_content);
        f.setBackgroundColor(getIntDef("btn_emoji_bg_picker", -0));
        Drawable d = iv.getResources().getDrawable(R.drawable.abc_ab_share_pack_holo_dark);
        d.setColorFilter(getIntDef("emoji_selected_color_picker",-0), PorterDuff.Mode.SRC_IN);
    }

    public static int setColorEmojiselected() {
        return getIntDef("emoji_selected_view_color_picker",-0);
    }

    public static void setEmojiBGHeader(ViewGroup vg) {
        vg.setBackgroundColor(getIntDef("emoji_bg_header_color_picker", -0));
    }

    public static void setSetbghemoji(ViewGroup vg) {
        vg.findViewById(R.id.action_bar_activity_content).setBackgroundColor(getIntDef("emoji_bg_header_color_picker",-0));
        vg.findViewById(R.id.action_bar).setBackgroundColor(getIntDef("emoji_bg_header_color_picker", -0));
    }

    public static void setColorEmojiBG(ViewGroup vg) {
        FrameLayout  fl= (FrameLayout) vg.findViewById(R.id.action_bar);
        fl.setBackgroundColor(getIntDef("emoji_bg_body_color_picker", -0));
    }

    public static void setChatEarliewBG(Button btn) {
        btn.setTextColor(getIntDef("chat_load_earlier_msgs_text_color_picker", -0));
    }

    public static void setChatEarliewBG(View view) {
        view.setBackgroundColor(getIntDef("chat_load_earlier_msgs_bg_color_picker", -0));
    }

    public static void setCaptionColorPicker(TextView tv) {
        tv.setTextColor(getIntDef("caption_color_picker",-0));
    }

   public static void setInputKeyboard(InputMethodManager imm, int i, int c) {
        if(!getBoolPref(EhsanModsActivity, "open_keyboard_check")) {
            imm.toggleSoftInput(i, c);
        }
        }

    public static void setTextColorNameContacts(TextView tv) {
        tv.setTextColor(getIntDef("contacts_names_color_picker",Color.BLACK));
        tv.setTextSize((float) getIntPref(context, "conversations_contacts_names_size_picker"));
    }

    public static void setTextColorSaveContacts(TextView tv) {
        tv.setTextColor(getIntDef("contacts_type_color_picker",Color.BLACK));
        tv.setTextSize((float) getIntPref(context, "contacts_phone_type_size_picker"));
    }


    public static void setTextColorStatusContacts(TextView tv) {
        tv.setTextColor(getIntDef("contacts_status_color_picker",Color.BLACK));
        tv.setTextSize((float) getIntPref(context, "contacts_status_size_picker"));
    }

    public static void setColorBackContacts(ListView lv) {
        lv.setDivider(new ColorDrawable(getIntDef("contacts_row_divider_picker", 0)));
        if(EhsanMods.getBoolPref(context, "contacts_hide_divider_check")) {
            lv.setDividerHeight(0);
        }else{
            lv.setDividerHeight(1);
        }
    }

    public static void setColorBtnSend(Drawable d, Activity a) {
            d.setColorFilter(getIntDef("send_icon_color_picker", 0), PorterDuff.Mode.MULTIPLY);
    }

    public static void setColorHomeBar(ActionBar b,Activity c){
        b.setBackgroundDrawable(new ColorDrawable(EhsanMods.getIntDef("header_background_color_picker", EhsanMods.defColor)));
        b.setIcon(new ColorDrawable(EhsanMods.getIntDef("chats_header_icons_color_picker", Color.WHITE)));
        c.getWindow().setBackgroundDrawable(new ColorDrawable(EhsanMods.getIntDef("chats_bg_odd_color_picker", Color.WHITE)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            c.getWindow().setStatusBarColor(getIntDef("chats_transparent_mode_sb_color_picker", EhsanMods.defColor));
            c.getWindow().setNavigationBarColor(getIntDef("chats_transparent_mode_nav_color_picker", EhsanMods.defColor));
        }
    }

    public static void setColorChatBar(ActionBar b,Activity v){
        b.setBackgroundDrawable(new ColorDrawable(EhsanMods.getIntDef("chat_header_background_color_picker", EhsanMods.defColor)));
        v.getWindow().setBackgroundDrawable(new ColorDrawable(EhsanMods.getIntDef("background_color_picker", Color.WHITE)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            v.getWindow().setStatusBarColor(getIntDef("chat_transparent_mode_sb_color_picker",EhsanMods.defColor));
            v.getWindow().setNavigationBarColor(getIntDef("chat_transparent_mode_nav_color_picker",EhsanMods.defColor));
        }
    }

    public static MenuItem setOpMenuItemColor(MenuItem vg, int i){
        return vg.setIcon(EhsanMods.getDrawableColor(context, "chat_header_icons_color_check", Color.WHITE, i));
    }

    public static void setColorTitleCountStrip(TextView a){
        a.setTextColor(EhsanMods.getIntDef("pagetitle_picker", Color.WHITE));
    }

    public static void setColorTitleCountStripSel(TextView b,int mselected){
        if(mselected==(-0x7f000001)) try {
        b.setTextColor(EhsanMods.getIntDef("pagetitle_sel_picker", Color.WHITE));
        } catch (Exception e) {
        }
    }

    public static void setIconMsgStripColorChats(TextView tv){
            tv.setTextColor(getIntDef("msg_badge_picker", defColor));
            tv.setBackgroundDrawable(getDrawableColor(context, "title_badgebg_picker", Color.WHITE, 0x7f02065b));
    }


    public static Drawable getBubbleColorLeft(Drawable drawable) {
        drawable.setColorFilter(new
                PorterDuffColorFilter(EhsanMods.getIntDef("grey_bubble_color_picker",EhsanMods.defColor), PorterDuff.Mode.MULTIPLY));
        return drawable;
    }

    public static Drawable getBubbleColorRight(Drawable drawable) {
        drawable.setColorFilter(new
                PorterDuffColorFilter(EhsanMods.getIntDef("green_bubble_color_picker", EhsanMods.defColor), PorterDuff.Mode.MULTIPLY));
        return drawable;
    }

    //Color codes end.

    public static void getCreateShortcutIcon(Activity b){
        Intent shortcutIntent = new Intent(b, App.class);
        shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Intent addIntent = new Intent();
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, EhsanMods.getString("app_name", b));
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, Intent.ShortcutIconResource.fromContext(b, EhsanMods.getIconApp(b)));
        addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
        b.sendBroadcast(addIntent);
    }

    public static int getBubbleDrawableID(int optionID) {
        final SharedPreferences settings = context.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE);
        String bubbleID = settings.getString("conversation_bubbleStyle", "0");
        int incoming_normal, incoming_normal_ext, outgoing_normal, outgoing_normal_ext, input;
        switch (bubbleID) {
            case "0":
                incoming_normal = 0x7f020069;
                incoming_normal_ext = 0x7f02006a;
                outgoing_normal = 0x7f020071;
                outgoing_normal_ext = 0x7f020072;
                input = 0x7f02051e;
                break;
            case "1":
                incoming_normal = 0x7f02063a;
                incoming_normal_ext = 0x7f02063b;
                outgoing_normal = 0x7f02063c;
                outgoing_normal_ext = 0x7f02063d;
                input = 0x7f020642;
                break;
            case "2":
                incoming_normal = 0x7f02063e;
                incoming_normal_ext = 0x7f02063f;
                outgoing_normal = 0x7f020640;
                outgoing_normal_ext = 0x7f020641;
                input = 0x7f020643;
                break;
            case "3":
                incoming_normal = 0x7f020644;
                incoming_normal_ext = 0x7f020645;
                outgoing_normal = 0x7f020646;
                outgoing_normal_ext = 0x7f020647;
                input = 0x7f020648;
                break;
            case "4":
                incoming_normal = 0x7f020649;
                incoming_normal_ext = 0x7f02064a;
                outgoing_normal = 0x7f02064b;
                outgoing_normal_ext = 0x7f02064c;
                input = 0x7f02064d;
                break;
            case "5":
                incoming_normal = 0x7f02064e;
                incoming_normal_ext = 0x7f02064f;
                outgoing_normal = 0x7f020650;
                outgoing_normal_ext = 0x7f020651;
                input = 0x7f020652;
                break;
            case "6":
                incoming_normal = 0x7f020653;
                incoming_normal_ext = 0x7f020654;
                outgoing_normal = 0x7f020655;
                outgoing_normal_ext = 0x7f020656;
                input = 0x7f020657;
                break;
            default:
                incoming_normal = 0x7f020069;
                incoming_normal_ext = 0x7f02006a;
                outgoing_normal = 0x7f020071;
                outgoing_normal_ext = 0x7f020072;
                input = 0x7f02051e;
                break;
        }

        switch (optionID) {
            case 0:
                return incoming_normal;
            case 1:
                return incoming_normal_ext;
            case 2:
                return outgoing_normal;
            case 3:
                return outgoing_normal_ext;
            case 4:
                return input;
        }

        return incoming_normal;
    }

    public static int getBubbleTick(int optionID) {
        final SharedPreferences settings = context.getSharedPreferences(PREFS_NAME, Activity.MODE_PRIVATE);
        String bubbleID = settings.getString("conversation_bubbleTickStyle", "0");
        int message_unsent,
                message_got_receipt_from_server,
                message_got_receipt_from_target,
                message_got_read_receipt_from_target,
                message_unsent_onmedia,
                message_got_receipt_from_server_onmedia,
                message_got_receipt_from_target_onmedia,
                message_got_read_receipt_from_target_onmedia;
        switch (bubbleID) {
            case "0":
                message_unsent = 0x7f020556;
                message_got_receipt_from_server = 0x7f020552;
                message_got_receipt_from_target = 0x7f020554;
                message_got_read_receipt_from_target = 0x7f020550;
                message_unsent_onmedia = 0x7f020557;
                message_got_receipt_from_server_onmedia = 0x7f020553;
                message_got_receipt_from_target_onmedia = 0x7f020555;
                message_got_read_receipt_from_target_onmedia = 0x7f020551;
                break;
            case "1":
                message_unsent = 0x7f020658;
                message_got_receipt_from_server = 0x7f020659;
                message_got_receipt_from_target = 0x7f02065a;
                message_got_read_receipt_from_target = 0x7f02065b;
                message_unsent_onmedia = 0x7f02065c;
                message_got_receipt_from_server_onmedia = 0x7f02065d;
                message_got_receipt_from_target_onmedia = 0x7f02065e;
                message_got_read_receipt_from_target_onmedia = 0x7f02065f;
                break;
            case "2":
                message_unsent = 0x7f020660;
                message_got_receipt_from_server = 0x7f020661;
                message_got_receipt_from_target = 0x7f020662;
                message_got_read_receipt_from_target = 0x7f020663;
                message_unsent_onmedia = 0x7f020664;
                message_got_receipt_from_server_onmedia = 0x7f020665;
                message_got_receipt_from_target_onmedia = 0x7f020666;
                message_got_read_receipt_from_target_onmedia = 0x7f020667;
                break;
            case "3":
                message_unsent = 0x7f020668;
                message_got_receipt_from_server = 0x7f020669;
                message_got_receipt_from_target = 0x7f02066a;
                message_got_read_receipt_from_target = 0x7f02066b;
                message_unsent_onmedia = 0x7f02066c;
                message_got_receipt_from_server_onmedia = 0x7f02066d;
                message_got_receipt_from_target_onmedia = 0x7f02066e;
                message_got_read_receipt_from_target_onmedia = 0x7f02066f;
                break;
            case "4":
                message_unsent = 0x7f020670;
                message_got_receipt_from_server = 0x7f020671;
                message_got_receipt_from_target = 0x7f020672;
                message_got_read_receipt_from_target = 0x7f020673;
                message_unsent_onmedia = 0x7f020674;
                message_got_receipt_from_server_onmedia = 0x7f020675;
                message_got_receipt_from_target_onmedia = 0x7f020676;
                message_got_read_receipt_from_target_onmedia = 0x7f020677;
                break;
            case "5":
                message_unsent = 0x7f020678;
                message_got_receipt_from_server = 0x7f020679;
                message_got_receipt_from_target = 0x7f02067a;
                message_got_read_receipt_from_target = 0x7f02067b;
                message_unsent_onmedia = 0x7f02067c;
                message_got_receipt_from_server_onmedia = 0x7f02067d;
                message_got_receipt_from_target_onmedia = 0x7f02067e;
                message_got_read_receipt_from_target_onmedia = 0x7f02067f;
                break;
            default:
                message_unsent = 0x7f020556;
                message_got_receipt_from_server = 0x7f020552;
                message_got_receipt_from_target = 0x7f020554;
                message_got_read_receipt_from_target = 0x7f020550;
                message_unsent_onmedia = 0x7f020557;
                message_got_receipt_from_server_onmedia = 0x7f020553;
                message_got_receipt_from_target_onmedia = 0x7f020555;
                message_got_read_receipt_from_target_onmedia = 0x7f020551;
                break;
        }

        switch (optionID) {
            case 0:
                return message_unsent;
            case 1:
                return message_got_receipt_from_server;
            case 2:
                return message_got_receipt_from_target;
            case 3:
                return message_got_read_receipt_from_target;
            case 4:
                return message_unsent_onmedia;
            case 5:
                return message_got_receipt_from_server_onmedia;
            case 6:
                return message_got_receipt_from_target_onmedia;
            case 7:
                return message_got_read_receipt_from_target_onmedia;
        }

        return message_unsent;
    }



}
