package re.ehsan.plus;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by Mr_ehsan on 24/10/15.
 */
public class Popup extends PreferenceActivity implements Preference.OnPreferenceClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_popup", "xml"));
        PrefKeys();
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    private void PrefKeys(){
        findPreference("popup_background_color_picker").setOnPreferenceClickListener(this);
        findPreference("popup_message_text_color_picker").setOnPreferenceClickListener(this);
        findPreference("popup_text_entry_color_picker").setOnPreferenceClickListener(this);
        findPreference("popup_footer_background_color_picker").setOnPreferenceClickListener(this);
        findPreference("popup_title_color_picker").setOnPreferenceClickListener(this);
        findPreference("popup_status_color_picker").setOnPreferenceClickListener(this);
        findPreference("popup_counter_color_picker").setOnPreferenceClickListener(this);
        findPreference("popup_buttons_text_color_picker").setOnPreferenceClickListener(this);
        findPreference("popup_locked_bg_color_picker").setOnPreferenceClickListener(this);
        findPreference("popup_send_icon_color_picker").setOnPreferenceClickListener(this);
        findPreference("popup_mic_icon_color_picker").setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference){
        if (preference.getKey().equals("popup_background_color_picker")) {
            EhsanMods.getShowColor(this,"popup_background_color_picker", Color.WHITE);

        } else if (preference.getKey().equals("popup_message_text_color_picker")) {
            EhsanMods.getShowColor(this, "popup_message_text_color_picker", Color.BLACK);

        } else if (preference.getKey().equals("popup_text_entry_color_picker")) {
            EhsanMods.getShowColor(this, "popup_text_entry_color_picker",Color.BLACK);

        }else if (preference.getKey().equals("popup_footer_background_color_picker")) {
            EhsanMods.getShowColor(this, "popup_footer_background_color_picker", Color.CYAN);

        }else if (preference.getKey().equals("popup_title_color_picker")) {
            EhsanMods.getShowColor(this, "popup_title_color_picker",Color.WHITE);

        }else if (preference.getKey().equals("popup_status_color_picker")) {
            EhsanMods.getShowColor(this,"popup_status_color_picker", Color.WHITE);

        }else if (preference.getKey().equals("popup_counter_color_picker")) {
            EhsanMods.getShowColor(this,"popup_counter_color_picker", Color.WHITE);

        }else if (preference.getKey().equals("popup_buttons_text_color_picker")) {
            EhsanMods.getShowColor(this,"popup_buttons_text_color_picker", Color.WHITE);

        }else if (preference.getKey().equals("popup_locked_bg_color_picker")) {
            EhsanMods.getShowColor(this,"popup_locked_bg_color_picker", Color.GRAY);
        }
        else if (preference.getKey().equals("popup_send_icon_color_picker")) {
            EhsanMods.getShowColor(this,"popup_send_icon_color_picker", Color.GRAY);
        }
        else if (preference.getKey().equals("popup_mic_icon_color_picker")) {
            EhsanMods.getShowColor(this,"popup_mic_icon_color_picker", Color.WHITE);
        }

        return EhsanMods.isRestart= true;
    }

}