package re.ehsan.plus;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by Mr_ehsan on 04/12/15.
 */
public class PreviewVideoBtn extends Button implements View.OnClickListener{

    public String url;

    public PreviewVideoBtn(Context context) {
        super(context);
        this.init();
    }

    public PreviewVideoBtn(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.init();
    }


    public PreviewVideoBtn(Context context, AttributeSet attrs, int defStyle){
        super(context, attrs, defStyle);
        this.init();
    }

    public void SetURL(String url){
        this.url= url;
        if(url== url){
            super.setVisibility(GONE);
        }
    } //endmet



    public void SetVisibility(int visibility) {
        if(!this.getTag().equals("Video"))
        {
            super.setVisibility(visibility);
        }
    }


    public void init() {
        this.setOnClickListener(this);
    }



    public void onClick(View v){
        if(url!=url){
            try {
                EhsanMods.getPreviewVideo(url, getContext());
            }catch(Exception e){
                Toast.makeText(this.getContext(), EhsanMods.getString("ENNoVA", getContext()), Toast.LENGTH_LONG).show();}
        }else{
            super.setVisibility(GONE);
            Toast.makeText(this.getContext(), EhsanMods.getString("ENErrURL", getContext()), Toast.LENGTH_LONG).show();
        }
    } //endmet



}