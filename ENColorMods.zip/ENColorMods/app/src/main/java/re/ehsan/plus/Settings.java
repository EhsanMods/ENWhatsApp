package re.ehsan.plus;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.wordpress.passcodelock.AppLockManager;

/**
 * Created by Mr_ehsan on 20/10/15.
 */
public class Settings extends PreferenceActivity implements OnPreferenceClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_settings", "xml"));
        EhsanMods.setEhsanModsDefault(this);
        findPreference("en_faqs").setOnPreferenceClickListener(this);
        findPreference("en_update").setOnPreferenceClickListener(this);
        findPreference("en_theme").setOnPreferenceClickListener(this);
        findPreference("en_chat").setOnPreferenceClickListener(this);
        findPreference("en_chats").setOnPreferenceClickListener(this);
        findPreference("en_popup").setOnPreferenceClickListener(this);
        findPreference("en_widget").setOnPreferenceClickListener(this);
        findPreference("en_media").setOnPreferenceClickListener(this);
        findPreference("en_other").setOnPreferenceClickListener(this);
        findPreference("en_donate").setOnPreferenceClickListener(this);
        findPreference("en_plus").setOnPreferenceClickListener(this);
        findPreference("en_web").setOnPreferenceClickListener(this);
        findPreference("en_twitter").setOnPreferenceClickListener(this);
        findPreference("en_share").setOnPreferenceClickListener(this);
        findPreference("en_report").setOnPreferenceClickListener(this);
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference.getKey().equals("en_faqs")) {
            Intent i= new Intent("android.intent.action.VIEW", Uri.parse("http://www.ehsan.re"));
            this.startActivity(i);

        }else if(preference.getKey().equals("en_update")){
            Intent intent = new Intent(this, Update.class);
            this.startActivity(intent);

        }else if(preference.getKey().equals("en_theme")){
            Intent intent = new Intent(this, Theme.class);
            this.startActivity(intent);

        }else if(preference.getKey().equals("en_chat")){
            Intent intent = new Intent(this, Chat.class);
            this.startActivity(intent);

        }else if(preference.getKey().equals("en_chats")){
            Intent intent = new Intent(this, Chats.class);
            this.startActivity(intent);

        }else if(preference.getKey().equals("en_popup")){
            Intent intent = new Intent(this, Popup.class);
            this.startActivity(intent);

        }else if(preference.getKey().equals("en_widget")){
            Intent intent = new Intent(this, Widget.class);
            this.startActivity(intent);

        }else if(preference.getKey().equals("en_media")){
            Intent intent = new Intent(this, Media.class);
            this.startActivity(intent);

        }else if(preference.getKey().equals("en_other")){
            Intent intent = new Intent(this, Other.class);
            this.startActivity(intent);

        }else if(preference.getKey().equals("en_donate")){
            Intent i= new Intent("android.intent.action.VIEW", Uri.parse("https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ehsan2022%40hotmail%2ecom&lc=US&item_name=Donate%20to%20EhsanMods&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted"));
            this.startActivity(i);

        }else if(preference.getKey().equals("en_plus")){
            Intent i= new Intent("android.intent.action.VIEW", Uri.parse("https://plus.google.com/u/0/communities/105039905761791987988"));
            this.startActivity(i);

        }else if(preference.getKey().equals("en_web")){
            Intent i= new Intent("android.intent.action.VIEW", Uri.parse("http://www.ehsan.re"));
            this.startActivity(i);

        }else if(preference.getKey().equals("en_twitter")){
            Intent i= new Intent("android.intent.action.VIEW", Uri.parse("https://twitter.com/Mr_ehsan2012"));
            this.startActivity(i);

        }else if(preference.getKey().equals("en_share")){
            EhsanMods.getShare(this, EhsanMods.getString("ENShareSbj", this), EhsanMods.getString("ENShareBdy", this), EhsanMods.getString("ENShare", this));

        }else if(preference.getKey().equals("en_report")){
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("message/rfc822");
            i.putExtra(Intent.EXTRA_EMAIL  , new String[] { "info@ehsan.re" });
            i.putExtra(Intent.EXTRA_SUBJECT, EhsanMods.getString("EN_Version", this));
            try {
                startActivity(Intent.createChooser(i, "Send mail..."));
            } catch (android.content.ActivityNotFoundException ex) {
                Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
            }

        }

        return false;
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Monitor launch times and interval from installation
        FollowApp.onStart(this);
        // Show a dialog if criteria is satisfied
        FollowApp.showFollowDialogIfNeeded(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(EhsanMods.isRestart) {
            //EhsanMods.isRestart = false;
            EhsanMods.RestartApp();
        }
    }


}
