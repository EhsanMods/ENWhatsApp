package re.ehsan.plus;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * Created by Mr_ehsan on 24/10/15.
 */
public class Theme extends PreferenceActivity implements Preference.OnPreferenceClickListener {

    private static final String TAG = "Theme";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_theme", "xml"));
        findPreference("save_temp").setOnPreferenceClickListener(this);
        findPreference("load_pref_file").setOnPreferenceClickListener(this);
        findPreference("clear_pref_file").setOnPreferenceClickListener(this);
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference.getKey().equals("save_temp")) {
            EhsanMods.getSaveTheme(this);

        }else if(preference.getKey().equals("load_pref_file")){
            LoadTheme();

        }else if(preference.getKey().equals("clear_pref_file")){
            AlertDialog dialog = new AlertDialog.Builder(this).create();
            dialog.setTitle(EhsanMods.getString("Ehsan_RTS", this));
            dialog.setMessage(EhsanMods.getString("Ehsan_aryou", this));
            dialog.setButton(AlertDialog.BUTTON_POSITIVE, EhsanMods.getString("Ehsan_YES", this), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ResetEhsanMods();

                }


            });
            dialog.setButton(AlertDialog.BUTTON_NEGATIVE, EhsanMods.getString("en_dialog_cancel", this), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            dialog.setCancelable(true);
            dialog.show();
            return true;

        }

        return false;
    }

    private void ResetEhsanMods(){
        EhsanMods.ResetEhsanMods(this);
        EhsanMods.RestartApp();
    }


    private void LoadTheme(){
        Intent localIntent= new Intent(this, XMLXplorerActivity.class);
        localIntent.setAction("android.intent.action.GET_CONTENT");
        localIntent.putExtra("FILTER", ".xml");
        this.startActivityForResult(localIntent, 6384);
    }
}