package re.ehsan.plus;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by Mr_ehsan on 23/10/15.
 */
public class Update extends PreferenceActivity implements Preference.OnPreferenceClickListener {

    private ChangeLog cl = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_update", "xml"));
        cl = new ChangeLog(this);
        findPreference("en_chkup").setOnPreferenceClickListener(this);
        findPreference("en_down").setOnPreferenceClickListener(this);
        findPreference("en_change").setOnPreferenceClickListener(this);
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference.getKey().equals("en_chkup")) {
            EhsanMods.isOnline(this);
            new UpdateChecker(this).execute();

        } else if (preference.getKey().equals("en_down")) {
            Intent i= new Intent("android.intent.action.VIEW", Uri.parse("http://www.ehsan.re"));
            this.startActivity(i);

        }else if (preference.getKey().equals("en_change")) {
            Update.this.cl.getFullLogDialog().show();
        }

        return false;
    }



}