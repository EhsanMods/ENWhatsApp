package re.ehsan.plus;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by Mr_ehsan on 24/10/15.
 */
public class Widget extends PreferenceActivity implements Preference.OnPreferenceClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(EhsanMods.getResId(this, "en_widget", "xml"));
        PrefKeys();
        final SharedPreferences ehsan = getSharedPreferences("com.enwhatsapp_en", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(EhsanMods.defColor);
        LinearLayout root = (LinearLayout) findViewById(android.R.id.list).getParent().getParent().getParent();
        Toolbar bar = (Toolbar) LayoutInflater.from(this).inflate(EhsanMods.getResId(this, "en_settings_toolbar", "layout"), root, false);
        bar.setBackgroundColor(EhsanMods.defColor);
        root.addView(bar, 0);
        bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    private void PrefKeys(){
        findPreference("widget_bg_color_picker").setOnPreferenceClickListener(this);
        findPreference("widget_header_background_color_picker").setOnPreferenceClickListener(this);
        findPreference("widget_header_title_color_picker").setOnPreferenceClickListener(this);
        findPreference("widget_header_subtitle_color_picker").setOnPreferenceClickListener(this);
        findPreference("widget_contact_name_color_picker").setOnPreferenceClickListener(this);
        findPreference("widget_date_color_picker").setOnPreferenceClickListener(this);
        findPreference("widget_message_color_picker").setOnPreferenceClickListener(this);
        findPreference("widget_small_bg_color_picker").setOnPreferenceClickListener(this);
        findPreference("widget_counter_color_picker").setOnPreferenceClickListener(this);
        findPreference("widget_no_messages_color_picker").setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference){
        if (preference.getKey().equals("widget_bg_color_picker")) {
            EhsanMods.getShowColor(this,"widget_bg_color_picker", 0xff0000ff);

        } else if (preference.getKey().equals("widget_header_background_color_picker")) {
            EhsanMods.getShowColor(this, "widget_header_background_color_picker", Color.BLACK);

        } else if (preference.getKey().equals("widget_header_title_color_picker")) {
            EhsanMods.getShowColor(this, "widget_header_title_color_picker",Color.WHITE);

        }else if (preference.getKey().equals("widget_header_subtitle_color_picker")) {
            EhsanMods.getShowColor(this, "widget_header_subtitle_color_picker", Color.GRAY);

        }else if (preference.getKey().equals("widget_contact_name_color_picker")) {
            EhsanMods.getShowColor(this, "widget_contact_name_color_picker",Color.BLACK);

        }else if (preference.getKey().equals("widget_date_color_picker")) {
            EhsanMods.getShowColor(this,"widget_date_color_picker", Color.GRAY);

        }else if (preference.getKey().equals("widget_message_color_picker")) {
            EhsanMods.getShowColor(this,"widget_message_color_picker", Color.BLACK);

        }else if (preference.getKey().equals("widget_small_bg_color_picker")) {
            EhsanMods.getShowColor(this,"widget_small_bg_color_picker", Color.WHITE);

        }else if (preference.getKey().equals("widget_counter_color_picker")) {
            EhsanMods.getShowColor(this,"widget_counter_color_picker", Color.BLACK);
        }
        else if (preference.getKey().equals("widget_no_messages_color_picker")) {
            EhsanMods.getShowColor(this,"widget_no_messages_color_picker", Color.BLACK);
        }

        return EhsanMods.isRestart= true;
    }



    SharedPreferences.OnSharedPreferenceChangeListener check = new SharedPreferences.OnSharedPreferenceChangeListener(){
        public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            if(!key.equals("widget_header_title_size_picker")
                    && !key.equals("widget_header_subtitle_size_picker")
                    && !key.equals("widget_contact_name_size_picker")
                    && !key.equals("widget_date_size_picker")
                    || !key.equals("widget_message_size_picker"));

            {
                EhsanMods.isRestart= true;
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(check);
    }



    @Override
    protected void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(check);

    }
}

