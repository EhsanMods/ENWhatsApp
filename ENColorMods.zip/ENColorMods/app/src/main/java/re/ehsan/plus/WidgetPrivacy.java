package re.ehsan.plus;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.Toast;

/**
 * Created by Mr_ehsan on 07/12/15.
 */
public class WidgetPrivacy extends AppWidgetProvider {
    public void onUpdate(Context context, AppWidgetManager appWidgetManager,int[] appWidgetIds) {
        for(int i=0; i<appWidgetIds.length; i++){
            int currentWidgetId = appWidgetIds[i];
            Intent intent= new Intent(context, Update.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);

            PendingIntent pending = PendingIntent.getActivity(context, 0,intent, 0);
            RemoteViews views = new RemoteViews(context.getPackageName(),EhsanMods.getResId(context, "en_widget", "layout"));

            views.setOnClickPendingIntent(EhsanMods.getResId(context, "wdgicon", "id"), pending);
            appWidgetManager.updateAppWidget(currentWidgetId, views);
        }
    }
}
