package re.ehsan.plus;

import android.content.Context;

/**
 * Created by Mr_ehsan on 07/12/15.
 */
public class t {

    public static CharSequence a(Object b, Context cm) {
        // TODO Auto-generated method stub
        return null;
    }

}
